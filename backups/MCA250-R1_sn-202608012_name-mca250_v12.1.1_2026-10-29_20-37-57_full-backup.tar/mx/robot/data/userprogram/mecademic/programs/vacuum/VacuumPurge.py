# pylint: disable=invalid-name
"""
This programs implements the following commands that are integrated in the robot API to
force a vacuum purge from the MVK01 vacuum module.
The purge duration is controlled by command ``SetVacuumPurgeDuration``
- VacuumPurge()
- VacuumPurgeImmediate()
"""
from mecademicpy.tools import robot_model_support_vacuum

#pylint: disable=wildcard-import,unused-wildcard-import,unused-import, invalid-name
from mecascript.script_base import *


def VacuumPurge(duration: Optional[float] = None):
    """ Implementation of the VacuumPurge robot command """
    prev_duration: float = None
    if duration is not None:
        prev_duration = robot.GetVacuumPurgeDuration()
        robot.SetVacuumPurgeDuration(duration)

    robot.VacuumGrip()
    robot.Delay(0.01)
    robot.VacuumRelease()

    # Restore purge duration if appropriate
    if prev_duration is not None:
        robot.SetVacuumPurgeDuration(prev_duration)


def VacuumPurge_Immediate(duration: Optional[float] = None):
    """ Implementation of the VacuumPurge robot command """
    prev_duration: float = None
    if duration is not None:
        prev_duration = robot.GetVacuumPurgeDuration()
        robot.SetVacuumPurgeDuration_Immediate(duration)

    robot.VacuumGrip_Immediate()
    robot.sleep(0.01)
    robot.VacuumRelease_Immediate()

    # Restore purge duration if appropriate
    if prev_duration is not None:
        robot.SetVacuumPurgeDuration_Immediate(prev_duration)


class VacuumPurgeModule(MecaScriptBase):
    """ MecaScript class that registers 2 new vacuum-related commands to the robot: VacuumPurge, VacuumPurge_Immediate
    """

    def on_register(self):
        """ Called once when this program is loaded.
        """

        # This module is only supported on mg2 robots with a vacuum module
        if not robot_model_support_vacuum(robot.GetRobotInfo().robot_model):
            return

        # Use empty prefix to register the functions directly in the robot's API namespace
        self.set_prefix(prefix='')

        # Define the argument common for both commands
        arg_def = RegisteredArg(name='duration',
                                description=('Optional: Purge duration, in seconds. If not provided, '
                                             'the current purge duration is used (see SetVacuumPurgeDuration)'),
                                type=MxArgType.MX_ARG_TYPE_FLOAT)

        # Define the command and its documentation
        cmd_defs: list[RegisteredCommand] = []
        cmd_defs.append(
            RegisteredCommand(
                function=VacuumPurge,  # Python function to register
                description=('This command triggers air purge in the MVK01 vacuum and I/O module'
                             ' in order to eject a part.'),
                validate_args=False,  # No TCP argument validation, because the "duration" argument is optional
                cyclic_id=40100,
                command_type=MxRegisteredCmdType.MX_REGISTERED_CMD_TYPE_INLINE,
                args=[arg_def]))

        cmd_defs.append(
            RegisteredCommand(
                function=VacuumPurge_Immediate,  # Python function to register
                description=('This instantaneous command triggers air purge in the MVK01 vacuum and I/O module'
                             ' in order to eject a part.'),
                validate_args=False,  # No TCP argument validation, because the "duration" argument is optional
                cyclic_id=40101,
                command_type=MxRegisteredCmdType.MX_REGISTERED_CMD_TYPE_INLINE,
                args=[arg_def]))

        for cmd_def in cmd_defs:
            self.override_command(cmd_def)
