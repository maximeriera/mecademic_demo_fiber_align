"""
This file define the Robot class with "sidecar" mode.
"""
from __future__ import annotations

import inspect
import logging
from queue import Queue
from typing import Any, Optional, Tuple

import mecademicpy.mecascript_classes as mecascript
from colorama import Fore
from mecademicpy._robot_base import mecascript_global_function_decorator
# pylint: disable=wildcard-import,unused-wildcard-import,invalid-name
from mecademicpy.mx_robot_def import MxRobotStatusCode as mx_st
from mecademicpy.mx_robot_def import *
from mecademicpy.robot_classes import *
from mecademicpy.robot_initializer import RobotWithTools

STOP_PROGRAM_MESSAGE = "StopProgram requested"

STOP_PROGRAM_CAUSE = "StopProgram"


class RobotSideCar(RobotWithTools):
    """ Robot class decorated with sidecar functionalities.
    This class shall only be used when inside a sidecar application, not a user standard application.
    The creation of this class shall be automated by the sidecar launcher.

    This robot object will connect to the robot using a special connection mode that does not take the control of
    the robot, but that is allowed to register custom commands.

    The robot will add these custom command in it's commands dictionary so they become available to application
    that control the robot (using any protocol: TCP (Python or other language), EtherNet/IP, Profinet, EtherCAT, etc.).

    When an application calls one of the sidecar registered commands, the robot will forward the request to the sidecar
    program, which will call the corresponding registered command, which is then allowed to send commands
    to the robot.

    The sidecar thus provides "extension" or "customizations" to the robot APIs.
    """

    def __init__(self, script_utils: mecascript.ScriptUtils):
        """Initialize this base class"""
        # Registered commands and variables by cyclic ID
        self._mecascript_messages_handlers = {
            mx_st.MX_ST_SIDECAR_CMD_EXEC:  # 3202
            self._handle_sidecar_cmd_exec,
            mx_st.MX_ST_SIDECAR_CMD_STOP_PROGRAM:  # 3213
            self._handle_sidecar_cmd_stop,
            mx_st.MX_ST_UPDATE_LOADED_PROGRAMS:  # 3221
            self._handle_sidecar_loaded_programs,
            mx_st.MX_ST_SIDECAR_SAVED_PYTHON_FILE:  # 3223
            self._handle_sidecar_saved_python_file,
        }
        self.script_utils = script_utils
        self.embedded = False

        self._mecascript_msg_queue: Queue = None
        self._mecascript_awake_events_on_stop_program = True  # True if we must awake user events upon StopProgram
        self._mecascript_command_interrupt: Optional[MecademicInterruptBase] = None
        self._executing_sidecar_command = False
        self._executing_sidecar_command_pending = False
        self._executing_sidecar_raw_code_file_name: Optional[str] = None
        self._pending_sidecar_stop_msg: Optional[Message] = None
        self._force_sync_get_time: dict[str, int] = {}

        super().__init__()

    def _reset(self):
        """ Reset the class to defaults """
        if self._is_initialized:
            # Unregister all sidecar MecaScripts
            while len(self._mecascript_registered_commands) > 0:
                for command_name, _ in self._mecascript_registered_commands.items():
                    file_path = self._mecascript_registered_commands[command_name].file_path
                    self.mecascript_unregister_program(file_path)
                    break

        super()._reset()

    def _check_internal_states(self, just_check_if_connected=False):
        """ Extends base class _check_internal_states for sidecar applications """
        if not just_check_if_connected:
            # Check if we're a sidecar program that is asked to stop
            if self._mecascript_command_interrupt is not None:
                if self._rx_thread is not None and threading.get_ident() == self._rx_thread.ident:
                    # Let's not block internal commands (like auto watchdog)
                    pass
                else:
                    raise self._mecascript_command_interrupt

        super()._check_internal_states(just_check_if_connected)

    def _warn_if_blocking(self, fct_name: Optional[str] = None, if_paused: bool = False):
        """ See doc in base class """
        # Check if we're executing a sidecar inline function
        if (self._mecascript_executing_command is not None and self._mecascript_executing_command.command_type
                != mecascript.MxRegisteredCmdType.MX_REGISTERED_CMD_TYPE_CONTROLLING):
            if fct_name is None:
                fct_name = tools.get_parent_fct_name()
            self.LogTrace(
                (f"WARNING: {fct_name} was called from an 'inline' MecaScript program which should not block/wait"),
                level=logging.WARNING)

        super()._warn_if_blocking(fct_name, if_paused)

    #####################################################################################
    # Public methods
    #####################################################################################

    @mecascript_global_function_decorator
    def SetStopProgramInterruption(self, enabled: bool):
        """ Enable or disable interruption of waitable events in a sidecar program when StopProgram is called.

        When enabled, waitable events (like checkpoints) will be interrupted (raise InterruptException)
        when the main API sends StopProgram to stop the running program.

        To perform tasks before exiting (e.g., moving the robot to a safe position), the program can:
            - Catch the InterruptException
            - Disable interruption with SetStopProgramInterruption(False)
            - Perform cleanup (e.g., moving the robot to a safe position)
            - Exit
        """
        if (not enabled and self._mecascript_command_interrupt is not None
                and isinstance(self._mecascript_command_interrupt, IllegalAfterControllingCommandException)):
            # This interruption cannot be disabled
            return
        self._mecascript_awake_events_on_stop_program = enabled
        self._mecascript_update_interrupted()

    @mecascript_global_function_decorator
    def StopProgramRequested(self) -> bool:
        """ Tells if a mecascript being executed must be stopped.
        All 'controlling' commands should test this periodically (at least every second) and exit immediately
        if this function returns True.
        Caller may then call GracefulStopProgram() to know if a graceful termination is allowed.

        Returns:
            True if the sidecar command being executed shall stop immediately
        """
        return self._executing_sidecar_command and (not self._mecascript_command_continue or not self.IsConnected())

    @mecascript_global_function_decorator
    def PauseMotionRequested(self) -> bool:
        """ Tells if a mecascript being executed must be paused.
        This happens when the main API receives a `PauseMotion` command.
        See ``HandlePauseMotion`` for details about how to use handle robot pause motion requests.

        Returns
        -------
        bool
            True if pausing motion is requested
        """
        return not self._robot_events.on_mecascript_resumed.is_set()

    @mecascript_global_function_decorator
    def HandlePauseMotion(self, pause_and_resume: Optional[bool] = True, timeout: Optional[float] = None):
        """ Blocks a MecaScript execution while robot motion is paused by the main API.

        Pause motion requests from the main API should be handled as followed by a `controlling` MecaScript:

        - ``PauseMotionRequested()`` should be called periodically by the MecaScript being executed to know when
          motion must be paused.
        - When pause is requested, the MecaScript should determine an appropriate moment for pausing motion
          (e.g. after moving the robot to a safe position) then call ``HandlePauseMotion()``, which will effectively
          pause the robot motion and block until motion is resumed by the main API.

        The timeout parameter can be used in case the MecaScript needs ``HandlePauseMotion`` to return after a certain
        time for various reasons, such as to perform periodic tasks, check for other conditions,
        or avoid indefinite blocking.

        Notes
        -----
        At all times, a `controlling` MecaScript remains in control of the robot motion. It can decide when to apply
        a pause request, and when to resume motion. It may even ignore a pause or resume request if appropriate.
        However it is recommended to implement a behavior that corresponds to what the end-user expects when
        it requests a pause or resume of robot motion.

        Parameters
        ----------
        pause_and_resume
            When True, this function will automatically pause robot motion before waiting,
            and resume motion before returning.
            When False, this function will not pause or resume robot motion, caller is responsible to pause
            (if appropriate) before calling this function, and to resume motion after this function returns
            (when appropriate).
            Defaults to True.
        timeout
            Maximum time in seconds to wait for motion to be resumed. TimeoutException is raised if this timeout
            is reached. If None (default), will wait indefinitely.
            Defaults to None.
        """
        return super()._handle_mecascript_pause_motion(pause_and_resume=pause_and_resume, timeout=timeout)

    @mecascript_global_function_decorator
    def GracefulStopProgram(self) -> bool:
        """ Once StopProgramRequested returns True, this function will indicate if the program is allowed or not a
            'graceful' termination, i.e. it can call SetStopProgramInterruption(False) to disable the interruption
            and continue controlling the robot (e.g., move the robot to a safe position).

        Returns:
            True if the sidecar command stopping is allowed a graceful termination
        """
        return super()._graceful_stop_allowed()

    @mecascript_global_function_decorator
    def sleep(self, duration: float):
        """
        Pauses execution of this application (not the robot).
        Similar to Python's ``time.sleep``, but can be interrupted if the robot is no longer controllable
        (for example, when disconnected) of if StopProgram() requests this program to stop.

        Parameters
        ---------
        duration
            Sleep duration, in seconds.

        Raises
        ------
        StopProgramException
            The robot is requesting to stop this program
        InterruptException
            The robot became unavailable before the timeout
        """
        start_time = time.monotonic()
        while True:
            elapsed = time.monotonic() - start_time
            if elapsed >= duration:
                return
            if self.StopProgramRequested() and self._mecascript_awake_events_on_stop_program:
                raise StopProgramException(message="Sleep interrupted due to request to stop program",
                                           graceful=self._mecascript_fct_stop_graceful)
            if not self.IsConnected():
                raise InterruptException("Sleep interrupted due to disconnection with the robot")
            time.sleep(0.01)

    #####################################################################################
    # Internal methods (for usage by the mecascript framework itself)
    #####################################################################################

    def ConnectAsSidecar(self, address: str = MX_DEFAULT_ROBOT_IP):
        """Connect to the robot as a sidecar scripting engine"""
        return self._Connect(address=address,
                             enable_synchronous_mode=False,
                             disconnect_on_exception=False,
                             monitor_mode=False)

    def set_embedded(self):
        """ Indicate that we're the sidecar embedded in the robot """
        self.embedded = True

    def _add_trace_prefix(self, msg: str, level: Optional[int] = None) -> str:
        """ Add a prefix that colorizes warnings or errors and also indicates when this trace
        comes from sidecar executing code """
        msg = super()._add_trace_prefix(msg, level)
        # Add an additional prefix if this is called from a user MecaScript
        prefix = ''
        if self._mecascript_executing_command is None:
            if self._executing_sidecar_raw_code_file_name is not None:
                prefix += (tools.COLOR_RESET + Fore.BLUE + 'MecaPortal.' + self._executing_sidecar_raw_code_file_name
                           + ': ')
        else:
            prefix += tools.COLOR_RESET + Fore.BLUE + self._mecascript_executing_command.name + ': '
        return prefix + msg

    # pylint: disable=invalid-name
    def MecaScriptLogTrace(self,
                           trace: str,
                           level: Optional[int] = logging.INFO,
                           trace_id=MxUserTrace.MX_USER_TRACE_SIDE_CAR_LOG_TRACE):
        """ Wrapper for traces printed in this class. Will print to robot and locally.
        This function avoids printing both on stdout and on the robot (since the robot also gets our stdout in
        its log so it would make the trace appear twice).
        This function also does not raise any exception if disconnected from the robot. It will instead print to
        stdout.
        """
        initial_level = level
        force_local_print = False
        try:
            if level != logging.DEBUG and level != logging.ERROR and self.embedded and self.IsConnected():
                # We're embedded sidecar, meaning the robot will print out stdout in its log file. So it's not worth
                # both sending a LogTrace to the robot and printing to our stdout.
                # So we'll only use LogTrace (which will be more inline with other messages we send to the robot)
                # and skip local stdout print
                level = None
            self._log_trace_common(trace=trace, level=level, trace_id=trace_id)
        # pylint: disable=broad-exception-caught
        except Exception:
            # We could not send our trace to the robot, let's at least print it locally
            force_local_print = initial_level is not None
        finally:
            if force_local_print:
                self.logger.log(initial_level, f'{trace}{tools.COLOR_RESET}')

    def send_json_command(self, command: str, json_data: dict, meta_data: Optional[dict] = None):
        """ Send a JSON command to the robot"""
        with self._main_lock:
            self._check_internal_states()
            return self._send_json_command(command, json_data, meta_data)

    def mecascript_register_done(self):
        """ Called once all MecaScripts have been loaded and have finished registering their commands """
        with self._main_lock:
            self._send_command("SidecarRegisterDone")

    def mecascript_register_program(self, file_path: str):
        """ Called by sidecar MecaScripts that are loading

        Args:
            file_path (str): Path of the MecaScript file that is being loaded
        """
        self.MecaScriptLogTrace(f'Registering MecaScript {file_path}',
                                level=logging.DEBUG,
                                trace_id=MxUserTrace.MX_USER_TRACE_SIDE_CAR_REGISTRATION)
        # Note: There is nothing specific to do (yet) for registering a MecaScript. The program will then normally
        # register commands and variables, but here we have nothing to do

    def mecascript_unregister_program(self, file_path: str):
        """ Called by MecaScripts that are unloaded to unregister their commands

        Args:
            file_path (str): Name of the MecaScript file that is being unloaded and from which any registered command
            must be unregistered
        """
        self.MecaScriptLogTrace(f'Un-registering MecaScript {file_path}',
                                level=logging.DEBUG,
                                trace_id=MxUserTrace.MX_USER_TRACE_SIDE_CAR_REGISTRATION)
        # Unregister all commands from this MecaScript
        commands_to_unregister: list[str] = []
        for command_name, command in self._mecascript_registered_commands.items():
            if file_path == command.file_path:
                commands_to_unregister.append(command_name)
        for command_name in commands_to_unregister:
            self.mecascript_unregister_command(command_name)

    def mecascript_register_msg_queue(self, queue: Optional[Queue]):
        """Register a callback for handling messages that must be processed by the sidecar's main thread
        (and not the robot class internal thread).
        For example, messages telling the sidecar to execute a robot registered command.

        Args:
            queue (Queue): The queue to push sidecar messages to.
        """
        self._mecascript_msg_queue = queue

    def mecascript_register_command(self, command: mecascript.RegisteredCommand):
        """ Register a sidecar command.
        See documentation from @ref _Robot.mecascript_register_command

        Raises:
            PermissionError: Trying to register a command that's already registered
            KeyError: This command exists as a class method already.
                      Use mecascript_override_command if the intention is really to override an existing command.
        """
        # Make sure it does not already exist in in the robot class
        exists = hasattr(RobotSideCar, command.name)
        if exists:
            raise KeyError(f'Cannot register command {command.name}, it already exists in Robot class')
        # Also validate that parent folders are not already registered as commands
        parts = command.name.split('.')
        if hasattr(self, parts[0]):
            root_container = getattr(self, parts[0])
            if isinstance(root_container, mecascript.AttributeContainer):
                # Check each part of the new command path to make sure a command does not exist where we
                # want to create a container for a parent part of our command path
                for i in range(2, len(parts) + 1):
                    partial_parent = '.'.join(parts[1:i])
                    found_attr = root_container.get(partial_parent)
                    if found_attr is not None and not isinstance(found_attr, mecascript.AttributeContainer):
                        raise KeyError((f'Trying to register command {command.name} '
                                        f'but parent folder {parts[0] + "." + partial_parent} exists as a command'))
            else:
                # Not a container, this means a command exists with our prefix first part
                raise KeyError(f'Cannot register command {command.name}, {parts[0]} exists as a command')

        # Register this command
        self.MecaScriptLogTrace(f'Registering command {command.name}',
                                level=logging.DEBUG,
                                trace_id=MxUserTrace.MX_USER_TRACE_SIDE_CAR_REGISTRATION)
        self._mecascript_register_command(command)

    def mecascript_override_command(self, command: mecascript.RegisteredCommand):
        """ Override an existing command built-in this robot class.
        See documentation from @ref _Robot.mecascript_override_command

        Raises:
            PermissionError: This command is already registered
            KeyError: The command we're trying to override does not exist.
                      Use mecascript_register_command if the goal is to add a new non-existing command.
        """
        # Make sure it matches an existing command in the robot class
        original_command = self._get_registered_attr(command.name)
        if not original_command:
            raise KeyError(f'Trying to override command {command.name} but it does not exist')

        # Make sure that the command is not already overwritten
        if command.name in self._mecascript_registered_commands:
            conflicting_command = self._mecascript_registered_commands[command.name]
            raise PermissionError((f'Trying to override command {command.name} '
                                   f'but it is already registered by MecaScript {conflicting_command.file_path}'))

        # Now also compare the command arguments. We must override with a command that matches
        new_sig = inspect.signature(command.function)
        old_sig = inspect.signature(getattr(RobotSideCar, command.name))

        # The two functions must have the same parameter names
        new_args: list[str] = []
        old_args: list[str] = []
        for arg_name in new_sig.parameters:
            if arg_name != "self":
                new_args.append(arg_name)
        for arg_name in old_sig.parameters:
            if arg_name != "self":
                old_args.append(arg_name)
        if new_args != old_args:
            raise TypeError((f'Trying to register command {command.name} but argument names do not match: '
                             f'({", ".join(new_args)}), expecting ({", ".join(old_args)})'))

        is_mecascript_implementation = False
        if command.name in self._mecascript_static_global_functions:
            is_mecascript_implementation = self._mecascript_static_global_functions[
                command.name].is_mecascript_implementation
        if is_mecascript_implementation:
            # We expected this command to be registered by the robot
            self.MecaScriptLogTrace(f'{Fore.CYAN}Registered built-in command {command.name}',
                                    trace_id=MxUserTrace.MX_USER_TRACE_SIDE_CAR_REGISTRATION)
        else:
            self.MecaScriptLogTrace(f'{Fore.YELLOW}Overriding command {command.name}',
                                    trace_id=MxUserTrace.MX_USER_TRACE_SIDE_CAR_REGISTRATION)
        # Register this command (override existing command actually)
        self._mecascript_register_command(command)

    def mecascript_unregister_command(self, command_name: str):
        """Register one command that was previously registered
        (unregister from robot class, and from global namespace robot_global_commands.py)

        Args:
            command_name (str): Function name to unregister
        """
        if command_name in self._mecascript_overridden_commands:
            self.MecaScriptLogTrace(f'Restoring original command {command_name}',
                                    trace_id=MxUserTrace.MX_USER_TRACE_SIDE_CAR_REGISTRATION)
        else:
            self.MecaScriptLogTrace(f'Un-registering command {command_name}',
                                    level=logging.DEBUG,
                                    trace_id=MxUserTrace.MX_USER_TRACE_SIDE_CAR_REGISTRATION)
        self._mecascript_unregister_command(command_name)

    def mecascript_call_registered_command(self, command_name, *args, **kwargs) -> Any:
        """ Call a sidecar registered command by name """
        return self._mecascript_call_registered_command(command_name, None, *args, **kwargs)

    def mecascript_get_registered_commands(self, file_path: str) -> list[Tuple[str, str]]:
        """ See documentation for _mecascript_get_registered_commands """
        return super()._mecascript_get_registered_commands(file_path)

    def mecascript_get_registered_command(self, command_name: str) -> Optional[mecascript.RegisteredCommand]:
        """ See documentation for _mecascript_get_registered_command """
        return super()._mecascript_get_registered_command(command_name)

    def force_error(self, message: str, result=MxRobotStatusCode.MX_ST_CMD_FAILED):
        """ Force a robot error """
        force_error_args: dict = {
            MX_JSON_KEY_FORCE_ROBOT_ERROR_CODE: result,
            MX_JSON_KEY_FORCE_ROBOT_ERROR_MSG: message
        }
        self.send_json_command('-SidecarForceError', force_error_args)

    def send_sidecar_exec_done(self, command_name: str):
        """ Tell the robot that sidecar command execution has finished """
        exec_done_args: dict = {MX_JSON_KEY_SIDECAR_CMD_NAME: command_name}
        self._mecascript_executing_command = None
        self._set_sidecar_paused(False)
        self.send_json_command("-SidecarExecDone", exec_done_args)

    def get_sidecar_executing_command(self) -> mecascript.RegisteredCommand:
        return self._mecascript_executing_command

    def register_variable(self, variable: mecascript.RegisteredVariable):
        """ Register a global variable that will be available to TCP and cyclic APIs """
        self.MecaScriptLogTrace(f'Registering variable {variable.name}',
                                trace_id=MxUserTrace.MX_USER_TRACE_SIDE_CAR_REGISTRATION)

        # Make sure it does not already exist in among registered variables
        if variable.name in self._registered_vars_by_name:
            raise PermissionError(f'Cannot register variable {variable.name}, it already exists')

        # Register the variable
        super()._register_variable(variable)

    def unregister_variable(self, variable_name: str) -> Any:
        """Delete a variable previously registered with RegisterVariable

        Args:
            variable_name (str): Name of the variable to unregister

        Returns:
            any: The variable value before it gets deleted
        """
        self.MecaScriptLogTrace(f'Un-registering variable {variable_name}',
                                trace_id=MxUserTrace.MX_USER_TRACE_SIDE_CAR_REGISTRATION)
        # Unregister the cyclic ID (if any)
        super()._unregister_variable(variable_name)

    #####################################################################################
    # Private methods
    #####################################################################################

    def _handle_common_messages(self, message: Message):
        """ This function overrides the base class function and first check if the message is a request for this
            sidecar instance, if not it calls the base class standard handler """
        sidecar_handler = self._mecascript_messages_handlers.get(message.id)
        if sidecar_handler:
            sidecar_handler(message)
        else:
            super()._handle_common_messages(message)

    def _handle_sidecar_cmd_exec(self, message: Message):
        """ Handle message of type MX_ST_SIDECAR_CMD_EXEC """
        if self._mecascript_msg_queue is not None:
            self._executing_sidecar_command_pending = True
            self._mecascript_msg_queue.put(message)
        else:
            self.logger.info(f'Ignoring sidecar request (no handler attached): {message.data}')

    #pylint: disable=unused-argument
    def _handle_sidecar_cmd_stop(self, message: Message):
        """ Handle message of type MX_ST_SIDECAR_CMD_STOP_PROGRAM """
        graceful = False
        if message.json_data:
            json_data: dict = message.json_data[mecascript.MX_JSON_KEY_DATA]
            graceful = json_data.get(mecascript.MX_JSON_KEY_SIDECAR_STOP_GRACEFUL, False)

        if self._executing_sidecar_command:
            command_name = ""
            if self._mecascript_executing_command is None:
                # We're executing raw code, let's use the path of the file we're executing from
                command_name = self._program_execution_status.file_path
                self.logger.info(f'Request to stop code from {self._program_execution_status.file_path}')
            else:
                command_name = self._program_execution_status.file_path
                if graceful:
                    self.logger.info(f'Request to gracefully stop program {command_name} (no timeout)')
                else:
                    self.logger.info(f'Request to stop program {command_name}')

            if not graceful:
                # Stop automatic watchdog (that is enabled during "controlling" commands).
                # We expect the executing command to stop gracefully an launcher thread to takeover
                # and restart polling the robot.
                # If the command does not gracefully stop, the robot will clear motion,
                # disconnect from sidecar and report error.
                self.AutoConnectionWatchdog(False)
                # Explicitly poll the robot one last time with appropriate message
                self.ConnectionWatchdog(timeout=MX_SIDECAR_CONNECTION_TIMEOUT_SEC,
                                        message=f'Stopping command {command_name}')

            # Tell the executing program to stop
            #pylint: disable=protected-access
            self._mecascript_set_can_continue(can_continue=False, graceful=graceful)
        elif self._executing_sidecar_command_pending:
            # This means the rx thread (here) has received the StopProgram request before the sidecar launcher
            # thread had time to actually call the command.
            # In this case we will save this message for launcher thread to handle it itself later
            #
            self._pending_sidecar_stop_msg = message

    def _handle_sidecar_loaded_programs(self, message: Message):
        """ Handle message of type MX_ST_UPDATE_LOADED_PROGRAMS """
        if self._mecascript_msg_queue is not None:
            self._mecascript_msg_queue.put(message)
        else:
            self.logger.info(f'Ignoring sidecar request (no handler attached): {message.data}')

    def _handle_sidecar_saved_python_file(self, message: Message):
        """ Handle message of type MX_ST_SIDECAR_SAVED_PYTHON_FILE """
        if self._mecascript_msg_queue is not None:
            self._mecascript_msg_queue.put(message)
        else:
            self.logger.info(f'Ignoring sidecar request (no handler attached): {message.data}')

    def _mecascript_call_registered_command(self, command_name, timeout: Optional[float], *args, **kwargs) -> Any:
        """ Call a sidecar registered command by name """
        if command_name not in self._mecascript_registered_commands:
            user_msg = f'Failed to call sidecar command {command_name}, it is not registered'
            self.LogTrace(user_msg, logging.ERROR)
            raise NotFoundException(user_msg)

        command_to_call = self._mecascript_registered_commands[command_name]
        switching_to_controlling = False
        if (self._mecascript_executing_command is not None and self._mecascript_executing_command.command_type
                != mecascript.MxRegisteredCmdType.MX_REGISTERED_CMD_TYPE_CONTROLLING
                and command_to_call.command_type == mecascript.MxRegisteredCmdType.MX_REGISTERED_CMD_TYPE_CONTROLLING):
            # A non-controlling command is calling a controlling command. When this happens, we must:
            # - Tell the robot that we're now executing a "controlling" command
            #   (the robot will refuse any queued command at that moment, since we don't allow queuing during
            #   execution of a controlling command)
            # - Call the command
            # - Call _mecascript_set_can_continue(False) so any robot command called after this function call is
            #   also refused (by raising a StopProgramException), emulating on the Python side the fact that
            #   nothing is allowed to be queued after calling a controlling program.
            switching_to_controlling = True
            self._send_custom_command("SidecarEnterControllingMode")
        return_value = super()._mecascript_call_registered_command(command_name, timeout, *args, **kwargs)
        if switching_to_controlling:
            exception = IllegalAfterControllingCommandException(message=(
                "No robot commands can be called by a program after it calls a sub-program of type 'controlling'"))
            self._mecascript_set_can_continue(False, False, exception)
        return return_value

    def _mecascript_set_can_continue(self,
                                     can_continue: bool,
                                     graceful: bool,
                                     exception: Optional[MecademicInterruptBase] = None):
        """ Set if sidecar program is allowed to continue or must stop """
        self._mecascript_command_continue = can_continue
        self._mecascript_fct_stop_graceful = graceful
        if not graceful:
            self._mecascript_awake_events_on_stop_program = True
        self._mecascript_update_interrupted(exception)

    def _set_executing_sidecar_command(self, executing: bool, raw_code_file_name: Optional[str] = None):
        """ Set or clear the flag indicating that we're currently executing a sidecar user registered command """
        self._executing_sidecar_command = executing
        self._executing_sidecar_raw_code_file_name = raw_code_file_name if executing else None
        if executing:
            if self._pending_sidecar_stop_msg is not None:
                # We have been asked to stop the program before it was even started. Let's do it now
                self._handle_sidecar_cmd_stop(self._pending_sidecar_stop_msg)
                self._pending_sidecar_stop_msg = None
        else:
            self._executing_sidecar_command_pending = False
            self._pending_sidecar_stop_msg = None
        self._mecascript_update_interrupted()

    def _mecascript_update_interrupted(self, exception: Optional[MecademicInterruptBase] = None):
        """ Check various conditions that determine if a sidecar program must be awakened by interrupting
            events (or resumed by no longer interrupting events).
            The events are interrupted when:
            - A program is running (self._executing_sidecar_command)
            - The robot asked the program to stop (self._mecascript_command_continue)
            - The program accepted to be awakened upon stop request (self._mecascript_awake_events_on_stop_program)

        Args:
            exception (Optional[MecademicInterruptBase]): Optional exception to raise following this interrupted
                                                          program. If None, StopProgramException is raised.

        """
        with self._main_lock:
            new_interrupted = False
            if (self._executing_sidecar_command and not self._mecascript_command_continue
                    and self._mecascript_awake_events_on_stop_program):
                new_interrupted = True

            if new_interrupted is True and self._mecascript_command_interrupt is not None:
                # No change
                return
            if new_interrupted is False and self._mecascript_command_interrupt is None:
                # No change
                return

            if new_interrupted and self._mecascript_command_interrupt is None:
                if exception is not None:
                    self._mecascript_command_interrupt = exception
                else:
                    self._mecascript_command_interrupt = StopProgramException(
                        STOP_PROGRAM_MESSAGE, graceful=self._mecascript_fct_stop_graceful)
            if not new_interrupted:
                # Remove the interruption
                self._mecascript_command_interrupt = None

            # Let's add or remove the temporary interrupt on various interruptable events
            self._mecascript_update_interrupted_checkpoints()
            self._mecascript_update_interrupted_interruptable_events()
            self._mecascript_update_interrupted_robot_events()

    def _mecascript_update_interrupted_checkpoints(self):
        """ Add or remove a temporary interruption on checkpoint events, depending if the sidecar program is now
            allowed to continue or not.
        """
        for checkpoints_dict in [self._internal_checkpoints, self._user_checkpoints]:
            for checkpoints_list in checkpoints_dict.values():
                for event in checkpoints_list:
                    if self._mecascript_command_interrupt is not None:
                        event.add_tmp_interrupt(cause=STOP_PROGRAM_CAUSE, exception=self._mecascript_command_interrupt)
                    else:
                        event.remove_tmp_interrupt(cause=STOP_PROGRAM_CAUSE)

    def _mecascript_update_interrupted_interruptable_events(self):
        """ Add or remove a temporary interruption on user interruptable events, depending if the sidecar program is
            now allowed to continue or not.
        """
        for event_weakref in self._custom_response_events:
            event: InterruptableEvent = event_weakref()
            if event:
                if self._mecascript_command_interrupt:
                    event.add_tmp_interrupt(cause=STOP_PROGRAM_CAUSE, exception=self._mecascript_command_interrupt)
                else:
                    event.remove_tmp_interrupt(cause=STOP_PROGRAM_CAUSE)

    def _mecascript_update_interrupted_robot_events(self):
        """ Add or remove a temporary interruption on robot events, depending if the sidecar program is now
            allowed to continue or not.
        """
        if self._mecascript_command_interrupt:
            self._robot_events.add_tmp_interrupt_all(cause=STOP_PROGRAM_CAUSE,
                                                     exception=self._mecascript_command_interrupt)
        else:
            self._robot_events.remove_tmp_interrupt_all(cause=STOP_PROGRAM_CAUSE)

    def _must_force_sync(self, cyclical_cmd: Optional[str] = None) -> bool:
        """This function determines if we want to force a synchronous "get" request with the robot.
        Here is the implementation for the sidecar engine (normal Mecademicpy never forces sync)

        Args:
            cyclical_cmd (str): When this is cyclical data, this is the name of the command that is being called and
                                that may need to be "sync". In fact, cyclical data is not received at all on the
                                sidecar (performance reasons) and is queried on demand only.
                                For non-cyclical data (data that is received even-based) pass None.

        Returns:
            bool: True if the command must be sent synchronously, False if it can be sent either sync or async
        """
        now = time.monotonic()
        force_sync = False
        if self._executing_sidecar_raw_code_file_name is not None:
            # Always force sync when executing raw code (from MecaPortal generally).
            # This makes executing code from the MecaPortal in a .mxpy code behave like a mxprog (i.e. sending
            # request to the robot and seeing the response in the event log)
            force_sync = True
        elif cyclical_cmd is not None:
            # We're the sidecar. We will not receive periodic RT data from the robot. We're thus forced to
            # explicitly get the data from the robot... but no more than every millisecond (no worth going any faster)
            if cyclical_cmd in self._force_sync_get_time:
                if now - self._force_sync_get_time[cyclical_cmd] > 0.001:
                    force_sync = True
                else:
                    pass
            else:
                # First time we call this function, let's force synchronous get because we're the Sidecar and we don't
                # receive periodic updates from the robot
                force_sync = True

        if force_sync and cyclical_cmd is not None:
            self._force_sync_get_time[cyclical_cmd] = now
        return force_sync
