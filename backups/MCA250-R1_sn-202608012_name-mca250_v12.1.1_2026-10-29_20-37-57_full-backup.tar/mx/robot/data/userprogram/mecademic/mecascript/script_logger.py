""" This file must be included in all sidecar programs. It exports global defines """
# pylint: disable=wildcard-import,unused-wildcard-import,redefined-builtin
import builtins
import logging
import sys
import traceback
from typing import Optional

from mecascript.robot_sidecar import RobotSideCar

logger_robot: RobotSideCar = None


class RobotSafeLogger(logging.Logger):
    """
    A logger that bypasses the global logging lock and writes directly to logger_robot.LogTrace,
    avoiding deadlocks when the robot also uses the logger.
    """

    def _log(self, level, msg, args, exc_info=None, extra=None, stack_info=False, stacklevel=1):
        """Re-implementation of Python's Logger._log"""

        try:
            # Format the message
            if args:
                msg = msg % args
            if exc_info:
                if not isinstance(exc_info, tuple):
                    exc_info = sys.exc_info()
                exc_text = "".join(traceback.format_exception(*exc_info))
                msg = f"{msg}\n{exc_text}"

            # Send to robot if connected, else use real_print
            if logger_robot is not None and logger_robot.IsConnected():
                logger_robot.LogTrace(msg, level=level)
            else:
                builtins.real_print(msg)

        except Exception:  # pylint: disable=broad-exception-caught
            # Do not raise exceptions from logging
            builtins.real_print("[ERROR] Logging failure in RobotSafeLogger")
            builtins.real_print(traceback.format_exc())


def set_safe_logger_robot(logger_robot_to_set: Optional[RobotSideCar]):
    """ Set the global reference to the robot object for RobotSafeLogger """
    global logger_robot  # pylint: disable=global-statement
    logger_robot = logger_robot_to_set
    if logger_robot is not None:
        logger_robot.logger.setLevel(logging.INFO)


# ----- Replace the global logging system with RobotSafeLogger -----

# Set our logger class globally
logging.setLoggerClass(RobotSafeLogger)

# Re-create root logger
logging.root = RobotSafeLogger("root")
logging.Logger.root = logging.root
logging.Logger.manager.loggerDict["root"] = logging.root

# Root logger level
logging.root.setLevel(logging.INFO)

# Remove all handlers and disable propagation
logging.root.handlers.clear()
logging.root.propagate = False

# Ensure all existing child loggers inherit the root logger
for name, log in logging.Logger.manager.loggerDict.items():
    if isinstance(log, logging.Logger) and not isinstance(log, RobotSafeLogger):
        new_logger = RobotSafeLogger(name)
        new_logger.__dict__.update(log.__dict__)
        logging.Logger.manager.loggerDict[name] = new_logger
    elif isinstance(log, RobotSafeLogger):
        # Force level inheritance
        log.setLevel(logging.NOTSET)

# Ensure all calls to logging.getLogger() return RobotSafeLogger
logger = logging.getLogger()


def _redirected_print(*args, sep=' ', end='\n', file=None, flush=False):
    """Override of print that sends output to logging.info(), mimicking built-in behavior"""
    msg = sep.join(str(arg) for arg in args) + end
    msg = msg.rstrip('\n')
    try:
        logging.info(msg)
    except Exception:  # pylint: disable=broad-exception-caught
        # Fallback to real_print in case logging isn't ready
        builtins.real_print(msg)

    if file is not None:
        builtins.real_print(*args, sep=sep, end=end, file=file, flush=flush)


# Monkey-patch built-in print globally
if not hasattr(builtins, "real_print"):
    builtins.real_print = builtins.print
builtins.print = _redirected_print
