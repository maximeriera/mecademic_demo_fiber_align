""" This file defines base class from which all Python MecaScripts must derive from """
import logging
from pathlib import Path

#pylint: disable=wildcard-import,unused-wildcard-import
from mecademicpy.mecascript_classes import *

from mecascript.robot_sidecar import RobotSideCar

mxpy_suffix = ".mxpy"
mxpy_prepended_suffix_no_ext = "_prepended"
mxpy_prepended_suffix = mxpy_prepended_suffix_no_ext + ".py"
mxpy_template_filename = 'mecascript_template.py.in'


class MecaScriptBase:
    """ Base class for all Python MecaScripts """

    def __init__(self):
        """Constructor for a Python MecaScript class
        """
        self.logger = logging.getLogger(__name__)
        self.robot: RobotSideCar = None
        self.mecascript_type = MecaScriptType.PY

        self._file_relative_path = ""
        self._file_path = ""
        self._prefix_programs: Optional[str] = None
        self._prefix_vars: Optional[str] = None
        self._was_initialized = True

    def set_prefix(self, prefix: Optional[str] = None):
        """Used to customize the prefix of a MecaScript.
        This function shall be called during on_register.

        Args:
            prefix (str):   Alternate prefix for all commands and variables registered by this program.
                            If not provided, the file path (with / replaced by .) will be used as a default prefix.
        """
        if prefix is not None:
            # Use the provided prefix for both
            self._prefix_programs = prefix
            self._prefix_vars = prefix
        else:
            # Build a default prefix by using file path, replacing / by .
            self._prefix_programs = MX_PROGRAMS_PREFIX
            self._prefix_vars = ""
            if self.mecascript_type == MecaScriptType.MXPY:
                # For .mxpy, we remove the file name since it's the same as the command name
                sub_path = self._file_relative_path.parent.as_posix().replace('/', '.').strip('.')
            else:
                # For .py we use the whole file path (without extension) as a prefix
                sub_path = self._file_relative_path.with_suffix('').as_posix().replace('/', '.').strip('.')
            if sub_path != '':
                self._prefix_programs = MX_PROGRAMS_PREFIX + "." + sub_path
                self._prefix_vars = sub_path

    def on_register(self):
        """ Will be overwritten by child class to register its functions """
        pass

    def on_unregister(self):
        """ May be overwritten by child class """
        pass

    def register_command(self, command: RegisteredCommand):
        """Register a command in the robot class so it can be called by other programs

        Args:
            command (RegisteredCommand): Command to register
        """
        # Prepare the command (enforce prefix)
        self._prepare_command(command, add_prefix=True)
        command.is_override = False
        # Register it
        self.robot.mecascript_register_command(command)

    def override_command(self, command: RegisteredCommand):
        """ Override an existing command from the Robot class with a custom implementation """
        # Prepare the command (enforce prefix)
        self._prepare_command(command, add_prefix=False)
        command.is_override = True  # Remember that this command is an override of an existing robot command
        # Register it
        self.robot.mecascript_override_command(command)

    def create_variable(self,
                        name: str,
                        value: Any,
                        cyclic_id: Optional[int] = None,
                        override: bool = False,
                        volatile: bool = False,
                        variableType: MxVariableType = MxVariableType.MX_VARIABLE_TYPE_JSON,
                        timeout: Optional[float] = 1.0):
        """ Same as robot.CreateVariable, with the following differences:
            - The program prefix is automatically added as a prefix for the variable name
            - The timeout is 1 second by default (vs None), making this function blocking.
              This is to ensure that when it returns, the robot has confirmed creation of the variable and that
              `robot.variables.(prefix).(var_name)` exists so the remainder of the program initialization can use it.

        See documentation in CreateVariable method in base class Robot for parameter description.
        """
        # Prepare the variable name (enforce prefix)
        if self._prefix_vars != '':
            name = f'{self._prefix_vars}.{name}'

        # Register it
        self.robot.CreateVariable(name=name,
                                  value=value,
                                  cyclic_id=cyclic_id,
                                  override=override,
                                  volatile=volatile,
                                  variableType=variableType,
                                  timeout=timeout)

    #pylint: disable=invalid-name
    def LogTrace(self, string: str):
        """ Log a trace on the console (info level) and on the robot"""
        self.robot.MecaScriptLogTrace(string)

    def get_file_path(self) -> str:
        """ Get the file path of this MecaScript"""
        return self._file_path

    #
    # Private methods
    #
    def _init_mecascript(self, file_path: str, mecascript_type: MecaScriptType, robot: RobotSideCar):
        """Complete the initialization of this class, before calling user's on_register command.

        Args:
            file_path (str): Relative path of this file (where it was loaded from)
            mecascript_type (MecaScriptType): Type of this MecaScript (mxpy or py)
            robot (RobotSideCar): The robot object we're using in this sidecar engine
        """
        self._set_file_path(file_path)
        self.mecascript_type = mecascript_type
        self.robot = robot

        # Register ourself as a loaded program
        self.robot.mecascript_register_program(self._file_path)

    def _term_mecascript(self):
        """ Explicitly called by launcher when the program is unloaded """
        if not hasattr(self, 'robot') or not hasattr(self, '_file_path'):
            return  # We were not properly initialized, no need to unregister

        # Unregister ourself as a loaded program
        self.robot.mecascript_unregister_program(self._file_path)

    def _set_file_path(self, file_path: str):
        """ Called by the MecaScript framework after __init__"""

        if not hasattr(self, '_was_initialized'):
            raise SyntaxError(f'MecaScriptBase.__init__() was not called. Did you forget to call super().__init__()?')

        file_relative_path = Path(file_path)

        if file_relative_path.name.endswith(mxpy_suffix):
            self.mecascript_type = MecaScriptType.MXPY

        self._file_relative_path = file_relative_path
        self._file_path: str = self._file_relative_path.as_posix()
        self._prefix_programs: Optional[str] = None
        self._prefix_vars: Optional[str] = None

        self.set_prefix(None)

    def _prepare_command(self, command: RegisteredCommand, add_prefix=True):
        """ Prepare a command for being registered (insert prefix)"""
        command.file_path = self._file_path
        command.mecascript_type = self.mecascript_type
        if add_prefix:
            if self._prefix_programs != '':
                command.name = f'{self._prefix_programs}.{command.name}'
        if command.command_type is None:
            # Function type is mandatory for sidecar commands, let's use default
            command.command_type = MxRegisteredCmdType.MX_REGISTERED_CMD_TYPE_INLINE
