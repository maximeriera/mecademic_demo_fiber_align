""" This file defines a context for executing custom code snippets with this Python MecaScript engine """
#pylint: disable=wildcard-import,unused-wildcard-import, unused-import
import code
import copy  # Unused, but leave this here so it's available when executing raw code from MecaPortal
import math  # Unused, but leave this here so it's available when executing raw code from MecaPortal
import textwrap
from typing import Callable, Optional

from mecademicpy.mecascript_classes import _register_nested_function, _unregister_nested_function
from mecademicpy.mx_robot_def import *
from mecademicpy.robot import Robot, RobotSilentApiMode

from mecascript.mecascript_base import *
from mecascript.mecascript_globals import *

console: code.InteractiveConsole = None
prev_indent = 0

shared_globals = {}


# pylint: disable=redefined-outer-name
def exec_mecascript_code(raw_code: str, first_line_idx: int):
    """This function executes a code snipped with this scripting engine

    Args:
        raw_code (str): Code to execute
    """
    if 'robot' not in shared_globals or shared_globals['robot'] is None:
        initialize_globals()

    # Remove extra indentation
    raw_code_dedent = textwrap.dedent(raw_code)

    use_exec = True
    if use_exec:
        # Insert blank lines so the line number here matches the line number in the source file from which
        # we're executing partial code
        if first_line_idx > 0:
            max_first_line = 15000  # Let's not insert exaggerated number of blank lines!
            if first_line_idx > max_first_line:
                first_line_idx = max_first_line
            raw_code_dedent = '\n' * first_line_idx + raw_code_dedent

        # pylint: disable=exec-used
        exec(raw_code_dedent, shared_globals)
    else:
        lines = raw_code_dedent.splitlines()
        for line in lines:
            indent = len(line) - len(line.lstrip())
            # pylint: disable=global-statement
            global prev_indent

            if indent < prev_indent:
                # Force an empty line to complete the block (console expects a blank line)
                console.push('\n')
            console.push(line)

            prev_indent = indent


def initialize_globals():
    """ This function is called to initialize the shared globals that will be used when executing user's code"""
    # pylint: disable=global-statement
    global shared_globals, prev_indent, console

    # Start with a copy of this module globals so the executed code sees imports like math, copy, etc.
    shared_globals = globals().copy()

    robot = globals().get('robot')

    # Ensure builtins are present for exec (usually present but explicit is safer)
    if "__builtins__" not in shared_globals:
        shared_globals["__builtins__"] = __builtins__

    # Create a watcher that injects/removes names into/from shared_globals
    def _make_watcher(globals_dict):

        def _get_global(attr_name: str) -> any:
            """ This helper function is used to get an attribute from the global namespace of the calling function """
            return globals_dict[attr_name] if attr_name in globals_dict else None

        def _set_global(attr_name: str, attr_val: any):
            """ This helper function is used to set an attribute from the global namespace of the calling function """
            globals_dict[attr_name] = attr_val

        def _del_global(attr_name: str):
            """ This helper function is used to delete an attribute from the global namespace
            of the calling function """
            if attr_name in globals_dict:
                del globals_dict[attr_name]

        def _watcher(register: bool, name: str, function: Optional[Callable]):
            """This function will be called when the Robot class needs to inform us of a global function that
            must be made available to the executed code (like 'MoveJoints', or any user program that registers
            without prefix, in the global namespace).

            Args:
                register: Register (else unregister) a global function
                name: Name of the function to register
                function: Global function pointer to register
            """
            if register:
                if name in globals_dict:
                    if globals_dict[name] == function:
                        robot.logger.warning(f'Executor: Warning: Global {globals_dict[name]} is registered twice')
                    else:
                        robot.logger.warning(
                            f'Executor: Warning: Overriding global {globals_dict[name]} with {function}')
                #pylint: disable=protected-access
                _register_nested_function(function_full_name=name,
                                          get_parent_attr=_get_global,
                                          set_parent_attr=_set_global,
                                          function=function)
            else:
                #pylint: disable=protected-access
                _unregister_nested_function(function_full_name=name,
                                            get_parent_attr=_get_global,
                                            del_parent_attr=_del_global)

        return _watcher

    # Instantiate a watcher bound to our new shared_globals and register it with the robot
    executor_watcher = _make_watcher(shared_globals)
    robot._mecascript_register_global_watcher(executor_watcher)  # pylint: disable=protected-access

    prev_indent = 0
    console = code.InteractiveConsole(locals=shared_globals)
