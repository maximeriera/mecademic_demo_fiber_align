"""
This file contains various tools and functions useful for mecascript package.
"""

import os
import pathlib
import site
import sysconfig
from typing import Callable, Optional, Union

from mecademicpy.tools import format_stack

import mecascript.mecascript_base as msb


def normalize_path(path: pathlib.Path) -> str:
    """ Returns a normalized path string from a Path object (useful to compare 2 paths)"""
    try:
        normalized_path = os.path.normcase(str(path.resolve(strict=False)))
    except Exception:  # pylint: disable=broad-exception-caught
        normalized_path = os.path.normcase(str(path))
    return normalized_path


python_lib_path = normalize_path(sysconfig.get_paths()["stdlib"])


def is_internal_file(file_path: Union[str, pathlib.Path]) -> bool:
    """Tells if the provided file path is located inside the mecademicpy or mecascript module

    Args:
        file_path (str): The path to test

    Returns:
        bool: True if the provided file path is located inside the mecademicpy or mecascript module
    """
    internal_folders = {'mecademicpy', 'mecascript'}
    path = pathlib.Path(file_path)
    path_norm = normalize_path(path)

    # Ignore pseudo-files like <string>, <frozen importlib._bootstrap>, etc.
    if "<" in str(path):
        return True

    # Check if path is inside the Python directory
    try:
        if os.path.commonpath([python_lib_path, path_norm]) == python_lib_path:
            return True
    except ValueError:
        # Note: commonpath raises ValueError on different drives on Windows
        pass

    # Check if path is inside "site-packages" (installed Python packages)
    site_paths = [normalize_path(pathlib.Path(p)) for p in site.getsitepackages() + [site.getusersitepackages()]]
    for site_path in site_paths:
        try:
            if os.path.commonpath([site_path, path_norm]) == site_path:
                return True
        except ValueError:
            continue

    # Detect files inside our own internal packages, like:
    # - In dev mode: "mecademicpy/mecademicpy/my_file"
    # - On the robot's editable packages: "mecademic/mecademicpy/my_file"
    parent = path.parent
    if parent.name in internal_folders:
        grandparent = parent.parent
        if grandparent and (grandparent.name == parent.name or grandparent.name == 'mecademic'):
            return True

    return False


def format_mecascript_stack(exception: Optional[Exception] = None,
                            format_callback: Optional[Callable[[str], str]] = None,
                            debug: Optional[bool] = False) -> list[str]:
    """See mecademicpy.format_stack for details.
    This function is similar, but reports a simplified call stack that only reports user files,
    not mecademicpy or mecascript internal files.

    Args:
        exception (Optional[Exception], optional): Exception to get stack from, otherwise getting current stack
        debug (Optional[bool], optional): When False, stack traces from "internal" code are removed, keeping only
            stack from user code

    Returns:
        list[str]: The formatted call stack, that contains user code only
    """
    stack_paths: list[str] = []
    stack = format_stack(exception=exception, format_callback=format_callback, stack_paths=stack_paths)

    if not debug:
        # Remove from the start and end of the stack all "internal" mecademicpy or mecascript files
        # (to keep only the portion of the call stack that represents user code, to simplify debugging for users)
        while len(stack_paths) > 0 and is_internal_file(stack_paths[0]):
            stack_paths.pop(0)
            stack.pop(0)
        while len(stack_paths) > 0 and is_internal_file(stack_paths[-1]):
            stack_paths.pop()
            stack.pop()

    if exception is not None:
        # Add the exception data itself as last line of the tack trace
        stack.append(f'    => {exception.__class__.__name__}: {exception}')

    # Make sure no "_prepended.py" file name appears in the printed file names
    stack = [line.replace(msb.mxpy_prepended_suffix, msb.mxpy_suffix) for line in stack]

    # Return the stack as a string
    return stack


def format_mecascript_stack_str(exception: Optional[Exception] = None,
                                format_callback: Optional[Callable[[str], str]] = None,
                                debug: Optional[bool] = False) -> str:
    """ Similar to format_mecascript_stack but formats as a single printable string with one stack item per line

    Returns:
        str: The call stack as a printable string
    """
    stack = format_mecascript_stack(exception, format_callback, debug)
    return '\n'.join(stack)
