""" This file must be included in all MecaScript Python program. It imports necessary global defines. """
# pylint: disable=wildcard-import,unused-wildcard-import,redefined-builtin
from mecademicpy.mx_robot_def import *
from mecademicpy.robot_classes import *

from mecascript.mecascript_base import *
from mecascript.mecascript_globals import *
