""" This application is the main entry point of the Sidecar Python application that loads user MecaScripts """
#!/usr/bin/env python3

import argparse
import logging
import sys
import time
from typing import List, Optional

app_args = None


def bootstrap_main():
    """ This function performs early application bootstrapping (args parsing) before we know the extra paths
    where we will be importing mecademic (and other extra) modules.
    Before this function only Python built-in modules should be imported
    """
    # pylint: disable=global-statement
    global app_args

    # Parse arguments
    parser = argparse.ArgumentParser(description='Launch a robot sidecar with selected MecaScripts.')
    parser.add_argument('--embedded', action='store_true', help='Run in embedded mode (inside the robot).')
    parser.add_argument('--extra_package', action='append', help='Additional folder to look for Python packages.')
    parser.add_argument('--ip', dest='ip', type=str, default=argparse.SUPPRESS, help='robot ip address.')
    parser.add_argument('--mecascript', action='append', help='A MecaScript path to load and register.')
    parser.add_argument('--no-log-file', action='store_true', help='Do not write log file, log on stdout only.')
    parser.add_argument('--debug', action='store_true', help='Debug mode (prints more information in stack traces).')

    app_args = parser.parse_args()

    extra_packages: Optional[List[str]] = app_args.extra_package
    if extra_packages is not None:
        for extra_package in extra_packages:
            print(f'Extra package path: {extra_package}')
            sys.path.insert(0, extra_package)


if __name__ == "__main__":
    bootstrap_main()

# pylint: disable=wrong-import-position
import faulthandler
import os
import pathlib
import signal
import traceback

# Must run before other Mecademic imports (i.e. before logging is used by Mecademic code)
# pylint: disable=C0411
from mecascript.script_logger import set_safe_logger_robot

# isort: split

import mecademicpy.robot as mdr
import mecademicpy.tools as tools
from colorama import Fore
from mecademicpy.mecascript_classes import ScriptUtils

import mecascript.mecascript_globals as mecascript_globals
from mecascript.launcher import MecaScriptLauncher
from mecascript.robot_sidecar import RobotSideCar

g_quit_requested = False

_robot: RobotSideCar = None  # pylint: disable=invalid-name
_launcher: MecaScriptLauncher = None  # pylint: disable=invalid-name

try:
    # Attach a signal handler that will dump all threads on SIGUSR1
    signal.signal(signal.SIGUSR1, lambda sig, frame: faulthandler.dump_traceback(sys.stdout, all_threads=True))
except AttributeError:
    # SIGUSR1 is not available on this platform (e.g., Windows), so we just skip it.
    pass


# pylint: disable=unused-argument, global-statement
def signal_handler(sig, frame):
    """ Handle user signal like pressing control-C """
    global g_quit_requested
    if not g_quit_requested:
        logging.info('')
        g_quit_requested = True
        if not _launcher or not _launcher.embedded:
            logging.info(f'{Fore.YELLOW}**********************************************')
            logging.info(f'{Fore.YELLOW}* Asked to quit (control-c pressed)')
            logging.info(f'{Fore.YELLOW}**********************************************')
            logging.info(f'{tools.COLOR_RESET}')
        if _launcher:
            _launcher.quit()
        if _robot is not None and _robot.IsConnected():
            _robot.Disconnect()


def launcher_app(robot: RobotSideCar, robot_ip: str, mecascript_paths: list[str], embedded=False, debug=False):
    """ Test launcher application """
    logger = logging.getLogger(__name__)
    logger.info(f'{tools.COLOR_RESET}Sidecar starting{" (embedded mode)" if embedded else ""}...')

    if embedded:
        robot.set_embedded()

    # Insert the CWD at the *beginning* of sys.path so the python modules can be imported
    sys.path.insert(0, os.getcwd())

    launcher = MecaScriptLauncher(robot, robot_ip, embedded, debug)
    global _launcher
    _launcher = launcher
    launcher.register_to_robot()
    if not launcher.embedded:
        launcher.set_local_mecascripts(mecascript_paths)

    launcher.check_robot_connection()

    while not g_quit_requested:
        try:
            if not embedded:
                launcher.reload_modified_mecascripts()

            # Wait for next message from the robot
            message: Optional[mdr.Message] = launcher.wait_message(timeout=0.1 if embedded else 0.01)
            if message is not None:
                launcher.handle_message(message)
        # pylint: disable=broad-exception-caught
        except Exception:
            # Print the exception, then continue (we'll try to reconnect to robot if necessary)
            traceback.print_exc()
            time.sleep(1)  # Sleep a bit to avoid infinite error loop

    launcher.unregister_from_robot()
    _launcher = None
    logger.info(f'{tools.COLOR_RESET}Sidecar stopped')


def main():
    tools.SetDefaultLogger(logging.INFO, '' if app_args.no_log_file else f'{pathlib.Path(__file__).stem}.log')

    # Attach signal handler in case we receive control-C (SIGINT) signal
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    if hasattr(signal, 'SIGBREAK'):
        signal.signal(signal.SIGBREAK, signal_handler)

    mecascript_globals.script_utils = ScriptUtils()
    with RobotSideCar(mecascript_globals.script_utils) as sidecar_robot:
        global _robot
        sidecar_robot._set_sidecar_mode(embedded=app_args.embedded)  # pylint: disable=protected-access
        mecascript_globals.bind_robot_instance(sidecar_robot)
        _robot = sidecar_robot
        set_safe_logger_robot(sidecar_robot)

        robot_ip = "127.0.0.1"
        if 'ip' in app_args:
            robot_ip = app_args.ip
        launcher_app(robot=mecascript_globals.robot,
                     robot_ip=robot_ip,
                     mecascript_paths=app_args.mecascript,
                     embedded=app_args.embedded,
                     debug=app_args.debug)
    mecascript_globals.robot = None
    set_safe_logger_robot(None)
    _robot = None


if __name__ == "__main__":
    main()
