""" This file exports some global variables used by mecascripts, like the robot object"""

from __future__ import annotations

import mecademicpy.mecascript_classes as mecascript

from mecascript.robot_sidecar import RobotSideCar

# Declare the global "robot" object that user programs will be able to use
robot: RobotSideCar = None
programs: mecascript.AttributeContainer = None
variables: mecascript.VariablesContainer = None

# Declare the global "script_utils" object that user programs will be able to use
script_utils: mecascript.ScriptUtils = None


def bind_robot_instance(sidecar_robot: RobotSideCar):
    """Bind the global Sidecar robot instance to the global resolver."""
    # Bind to the global variables
    # pylint: disable=global-statement
    global robot
    global programs
    global variables
    robot = sidecar_robot
    programs = sidecar_robot.programs
    variables = sidecar_robot.variables
