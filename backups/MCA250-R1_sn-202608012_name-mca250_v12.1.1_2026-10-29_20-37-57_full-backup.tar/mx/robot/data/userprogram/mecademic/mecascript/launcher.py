""" This file contains the code that is used to launch a sidecar application, including loading and launching
user-defined MecaScripts, and reloading them when appropriate.
"""
import builtins
import ctypes
import gc
import importlib
#!/usr/bin/env python3
import importlib.resources
import importlib.util
import inspect
import logging
import os
import pathlib
import platform
import queue
import re
import sys
import textwrap
import threading
import time
import traceback
import types
from pathlib import Path
from typing import Any, Callable, Optional, Tuple

import mecademicpy.mecascript_classes as mecascript
import mecademicpy.robot as mdr
import yaml
from mecademicpy.tools import interruptable_sleep
from yaml.error import YAMLError

import mecascript.mecascript_base as msb
from mecascript.robot_sidecar import RobotSideCar
from mecascript.tools import format_mecascript_stack_str, is_internal_file

# Global map: module_name -> set of modules it imported
g_module_dependencies: dict[str:set[str]] = {}

import_actual = builtins.__import__

MX_SIDECAR_HEAP_TRIM_MIN_INTERVAL_SEC = 10


def is_local_module(module_name: str) -> bool:
    """Return True if the module is part of the user's local code, not stdlib or site-packages."""
    spec = importlib.util.find_spec(module_name)
    if not spec or not spec.origin or spec.origin in ("built-in", "frozen"):
        return False

    path = os.path.realpath(spec.origin).lower()

    # Skip frozen importlib machinery
    if "importlib._bootstrap" in module_name or "importlib._bootstrap_external" in module_name:
        return False
    if "frozen" in path.replace("\\", "/"):
        return False

    # Skip stdlib and site-packages
    for p in (sys.prefix, sys.base_prefix):
        if path.startswith(os.path.realpath(os.path.join(p, "lib")).lower()):
            return False
    if "site-packages" in path or "dist-packages" in path:
        return False

    return True


#pylint: disable=redefined-builtin
def tracked_import(name, globals=None, locals=None, fromlist=(), level=0):
    """ This function override the built-in __import__ so we can keep track of which file imported which.
    We will use this information later to reload dependencies whenever a Python file is saved.
    """
    module = import_actual(name, globals, locals, fromlist, level)
    try:
        importer = globals.get("__name__") if globals else None
        if not importer:
            return module

        # Skip tracking imports involving pathlib to avoid recursive import issues since module_name_to_path()
        # below needs to use the Path module
        if name == "pathlib" or importer == "pathlib":
            return module
        # Check if this is one of our own local modules, and if it is, let's keep track of it
        if is_local_module(importer) and is_local_module(name):
            importer_path = PythonModuleLoader.module_name_to_path(importer).as_posix()
            path = PythonModuleLoader.module_name_to_path(name).as_posix()
            if os.path.exists(path) and os.path.exists(importer_path):
                # Add this "import" to the importer's list of dependencies
                deps = g_module_dependencies.setdefault(importer_path, set())
                deps.add(path)
    except Exception:  #pylint: disable=broad-exception-caught
        pass

    return module


# Remap the built-in __import__ to our tracked_import method which keeps track of all modules that import others
builtins.__import__ = tracked_import


class MecaScriptOptionsError(mdr.MecademicNonFatalException):
    """ Indicates an error parsing the mecascript_options of a user program """
    pass


def count_indent(s: str, tab_width=4) -> int:
    """Count the number of spaces in front of a line (indent count).
    Tabs are assumed to be 4 spaces wide, though this can't work all the time as there is no standard in Python.

    Parameters
    ----------
    s
        The string to count indentation for
    tab_width
        Indent width to apply to tab characters. Defaults to 4.

    Returns
    -------
        int: The indent count
    """
    indent = 0
    for ch in s:
        if ch == ' ':
            indent += 1
        elif ch == '\t':
            indent += tab_width - (indent % tab_width)
        else:
            break
    return indent


def is_integer_or_none(value: str) -> Tuple[bool, str]:
    """Validate that a value is an integer or 'None'

    Parameters
    ----------
    value
        Value to validate

    Returns
    -------
        (Result bool, error message string)
    """
    value = value.strip()
    if value == "None":
        return (True, "")
    if value.isdigit():
        return (True, "")
    return (False, "Expecting integer or None")


def is_yaml_string(value: str) -> Tuple[bool, str]:
    """ Validates that a YAML value is a string (possibly quoted)

    Parameters
    ----------
        value (str): Value to validate

    Returns
    -------
        If valid: (True, trimmed string value)
        If invalid: (False, error message)
    """
    value = value.strip()
    # quoted or bare text
    if (value.startswith('"') and value.endswith('"')) or \
       (value.startswith("'") and value.endswith("'")):
        return (True, value[1:-1])
    if not bool(value):
        # Empty string is not possible unless quoted
        return (False, "Expected a string value")
    return (True, value)


def is_command_type(value: str) -> Tuple[bool, str]:
    """ Validates that a YAML value is a string (possibly quoted)
    that represents the command_type ("inline" or "controlling")

    Parameters
    ----------
    value
        Value to validate

    Returns
    -------
    Tuple[bool,str]
        Result bool, error message string
    """
    valid, msg = is_yaml_string(value)
    if not valid:
        return (valid, msg)
    stripped_value = msg
    valid_values = ["inline", "controlling"]
    if stripped_value.lower() not in valid_values:
        return (False, f'Expected one of {valid_values}')
    return (True, "")


MECASCRIPT_OPTION_KEY_VALIDATORS: dict[str, Callable] = {
    mdr.MX_PROG_OPTION_CYCLIC_ID: is_integer_or_none,
    mdr.MX_PROG_OPTION_DESCRIPTION: is_yaml_string,
    mdr.MX_PROG_OPTION_COMMAND_TYPE: is_command_type,
}


def pre_validate_mecascript_options(lines: list[str], line_offset: int, options_indent):
    """ Performs a pre-validation of mecascript_options before calling the YAML parser.
    The goal is to identify common errors and report them clearly to the user, since the YAML parser is very bad
    at reporting clear errors!

    Parameters
    ----------
    lines
        Lines to validate
    line_offset
        Offset of the first line to validate within the whole user program
        (for accurate line number reporting in the exception)
    options_indent
        Expected indent for mecascript_options. Will raise if inconsistent ident

    Raises:
        MecaScriptOptionsError: The mecascript_options are considered invalid. Message explains why.
    """
    for line_no, line in enumerate(lines, start=1):
        line_no += line_offset
        stripped = line.strip()

        # Skip blank or comment-only lines
        if not stripped or stripped.startswith("#"):
            continue

        # Split at first colon (key / value # comment)
        if ":" not in stripped:
            raise MecaScriptOptionsError(f"Missing ':' on line {line_no}")
        key, rest = stripped.split(":", 1)

        if key == mdr.MX_MECASCRIPT_OPTIONS:
            continue

        # Validate indent
        current_indent = count_indent(line)
        if current_indent != options_indent:
            raise MecaScriptOptionsError(f"Unexpected indentation for '{key}' on line {line_no}")

        if key not in MECASCRIPT_OPTION_KEY_VALIDATORS:
            raise MecaScriptOptionsError(f"Unknown key '{key}' on line {line_no}. "
                                         f"Expected one of: {', '.join(MECASCRIPT_OPTION_KEY_VALIDATORS)}")

        # Colon must be followed by at least one space
        if rest and not rest.startswith(" "):
            raise MecaScriptOptionsError(f"Expected a space after ':' for key '{key}' on line {line_no}")

        # Separate value from comment.
        quote_delimiter = None
        value_with_comment = rest.lstrip()
        if value_with_comment[0] == '"' or value_with_comment[0] == "'":
            quote_delimiter = value_with_comment[0]
        if quote_delimiter is None:
            # Not a quoted string value. Comment must be space + #
            value = value_with_comment.split(" #", 1)[0]
        else:
            # Quote string. Value ends at closing delimiter
            value, _ = value_with_comment[1:].split(quote_delimiter, 1)
        value = value.rstrip()

        if not value:
            raise MecaScriptOptionsError(f"Missing value for key '{key}' on line {line_no}")

        validator = MECASCRIPT_OPTION_KEY_VALIDATORS[key]
        valid, msg = validator(value)
        if not valid:
            raise MecaScriptOptionsError(f"Invalid value for key '{key}' on line {line_no}. {msg}, but got {value!r})")


def find_mecascript_options(script_source: str) -> dict:
    """ Load mecascript_options yaml string found in the comments of the user's mxpy file and return it as a dict"""
    lines = script_source.splitlines()
    yaml_lines = []
    inside_mecascript_options = False
    base_indent = None
    options_indent = None

    mecascript_options_line_offset = 0
    for line in lines:
        if inside_mecascript_options:
            comment_match = re.match(r'^(\s*)#(.*)', line)
            if comment_match:
                yaml_line = comment_match.group(2)
                current_indent = count_indent(yaml_line)
                if current_indent <= base_indent:
                    # Indentation back to the level of "mecascript_options:" -> Stop capturing the yml options here
                    break
                # yaml_line = _fix_yaml_line(yaml_line)
                if options_indent is None:
                    options_indent = current_indent
                yaml_lines.append(yaml_line)
            else:
                break  # Stop on first non-comment line
        else:
            # Check if this line identifies mecascript options
            match = re.match(rf'^(\s*)#\s*{re.escape(mdr.MX_MECASCRIPT_OPTIONS)}:\s*(.*)', line)
            if match:
                comment_match = re.match(r'^(\s*)#(.*)', line)
                inside_mecascript_options = True
                yaml_line = comment_match.group(2)
                base_indent = count_indent(yaml_line)
                # yaml_line = _fix_yaml_line(yaml_line)
                yaml_lines.append(yaml_line)  # inline YAML after mecascript_options:
                continue
            else:
                mecascript_options_line_offset += 1
    if len(yaml_lines) == 0:
        return {}

    pre_validate_mecascript_options(yaml_lines, mecascript_options_line_offset, options_indent)

    yaml_text = '\n'.join(yaml_lines)

    try:
        yaml_data = yaml.safe_load(yaml_text).get('mecascript_options', {})
    except (YAMLError) as e:
        problem_str = getattr(e, 'problem', 'unknown reason')
        raise MecaScriptOptionsError((f'\nInvalid mecascript_options. YAML parser returned the following error:\n'
                                      f'{problem_str}')) from e
    return yaml_data


class PythonModuleLoader:
    """
    This class represents one python file to load (and execute).
    The python file is executed as it's being loaded (as usual in Python).
    This class provides methods to reload the file (thus re-execute it), and to conditionally reload it if
    the modification date has changed.
    """

    def __init__(self,
                 robot: RobotSideCar,
                 module_path: Optional[str] = None,
                 module_name: Optional[str] = None,
                 monitor_file: bool = False,
                 template_line_offset: Optional[int] = 0,
                 debug: Optional[bool] = False):
        """ Initialize this python file interpreter launcher class """
        self.robot = robot
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)
        self.module_path: Optional[str] = module_path
        self.monitor_file: bool = monitor_file
        self.loaded_cfg = False  # Tells if configuration requests to load this file
        self.loaded = False  # Tells if actually loaded (may not be if self.loaded_cfg but failed to load)
        self.reload_pending = False
        self._template_line_offset = template_line_offset
        self.debug = debug

        if module_path is None and monitor_file:
            raise ValueError('Cannot monitor file if module_path is not provided')

        if module_name is None:
            # If module_name is not provided, we will use the module_path to create a module name
            if module_path is None:
                raise ValueError('module_path and module_name cannot both be None')
            module_name: str = self.module_path_to_name(module_path)
        self.module_name: str = module_name

        self.logger.debug(f'PythonModuleLoader init with {self.module_name} from path "{self.module_path}"')
        if self.monitor_file:
            self._modification_time = os.path.getmtime(self.module_path)
        self.module: types.ModuleType = None

    def load(self):
        """ Load (or reload) the file from the disk """
        if self.module_path is not None:
            if self.module is None:
                self.robot.MecaScriptLogTrace(f'Loading "{self.module_path}"',
                                              level=logging.INFO,
                                              trace_id=mdr.MxUserTrace.MX_USER_TRACE_SIDE_CAR_REGISTRATION)
            else:
                self.robot.MecaScriptLogTrace(f'Reloading "{self.module_path}"',
                                              level=logging.INFO,
                                              trace_id=mdr.MxUserTrace.MX_USER_TRACE_SIDE_CAR_REGISTRATION)

        lineno = 0
        func_name = ""
        exception: Optional[Exception] = None
        line_offset = self._template_line_offset
        print_stack = True

        try:
            # Clear reload_pending before trying to load so we try only once per retry request
            self.loaded_cfg = True
            self.reload_pending = False
            self._load_module()
            self.loaded = True

        # pylint: disable=broad-exception-caught
        except SyntaxError as e:

            def adjust_line_number(msg: str) -> str:
                return re.sub(r'on line (\d+)', lambda m: f'on line {int(m.group(1)) - line_offset}', msg)

            exception = e
            e.lineno -= line_offset
            lineno = e.lineno
            message = adjust_line_number(e.msg)
        except MecaScriptOptionsError as e:
            exception = e
            lineno = 0
            message = f'{e}'
            print_stack = False
        except Exception as e:
            exception = e
            tb = traceback.extract_tb(e.__traceback__)[-1]
            _, lineno, func_name, _ = tb
            lineno -= line_offset
            message = f'{e}'

        if exception is not None:
            module_path = self.module_path.replace(msb.mxpy_prepended_suffix, msb.mxpy_suffix)
            if func_name == "":
                message = ((f'Exception raised while loading program {module_path}:\n{message}'))
            else:
                message = ((f'Exception raised while loading program {module_path} '
                            f'({func_name} at line {lineno}):\n{message}'))
            self.robot.MecaScriptLogTrace(message,
                                          level=logging.ERROR,
                                          trace_id=mdr.MxUserTrace.MX_USER_TRACE_SIDE_CAR_ERROR)

            if print_stack:
                #  Print call stack too, starting after mecascript_call_registered_command
                stack_str = format_mecascript_stack_str(exception, debug=self.debug)
                if stack_str != '':
                    self.robot.MecaScriptLogTrace(f'Exception trace:\n{stack_str}',
                                                  level=logging.ERROR,
                                                  trace_id=mdr.MxUserTrace.MX_USER_TRACE_SIDE_CAR_ERROR)
            raise mdr.InvalidConfigError(message)

    def __str__(self) -> str:
        """ Returns string representation """
        return self.module_name

    def __repr__(self) -> str:
        """ Returns string representation """
        return str(self)

    def is_changed(self) -> bool:
        """ Tells if the source file modification time has changed since it was loaded """
        if not self.monitor_file:
            return False

        modification_time = os.path.getmtime(self.module_path)
        if modification_time == self._modification_time:
            return False

        self._modification_time = modification_time
        return True

    @classmethod
    def module_path_to_name(cls, module_path) -> str:
        """ Convert a module path to Python module name.
        Example: my_module/my_sub_module -> my_module.my_sub_module
        """
        return module_path.replace(os.sep, '.').replace('/', '.').replace('.py', '')

    @classmethod
    def module_name_to_path(cls, module_name) -> Path:
        """ Convert a module name to path.
        Only implement (for now) for local modules in the working directory
        Example: my_module.my_sub_module -> my_module/my_sub_module
        """
        module_name = module_name.replace(msb.mxpy_prepended_suffix_no_ext, '')
        parts = module_name.split(".")
        py_path = Path(*parts).with_suffix(".py")
        return py_path

    def load_mxpy_from_template(self, script_file_path) -> str:
        """This function loads a .mxpy basic program.
        This program is integrated into a "wrapper" template (mecademicpy/mecascript_template.py.in)
        This template file contains tags that are replaced by the program name and code.

        Args:
            script_file_path (_type_): Path of the program file to load and wrap into a MecaScript program template

        Returns:
            str: Returns the program file wrapped inside a function registered by a MecaScript program
        """
        # Read the program file
        script_source = ""
        with open(script_file_path, 'r', encoding='utf-8') as f:
            script_source = f.read()

        cyclic_id = None
        script_description = ""
        command_type_str = None
        mecascript_options: dict = find_mecascript_options(script_source)
        if mecascript_options is not None:
            cyclic_id = mecascript_options.get(mdr.MX_PROG_OPTION_CYCLIC_ID, None)
            script_description = mecascript_options.get(mdr.MX_PROG_OPTION_DESCRIPTION, '')
            command_type_str: str = mecascript_options.get(mdr.MX_PROG_OPTION_COMMAND_TYPE, None)

        # Convert string to enum
        if command_type_str is None:
            command_type_str = 'MxRegisteredCmdType.MX_REGISTERED_CMD_TYPE_INLINE'
        elif 'inline' in command_type_str.lower():
            if 'unrestricted' in command_type_str.lower():
                command_type_str = 'MxRegisteredCmdType.MX_REGISTERED_CMD_TYPE_INLINE_UNRESTRICTED'
            else:
                command_type_str = 'MxRegisteredCmdType.MX_REGISTERED_CMD_TYPE_INLINE'
        elif 'controlling' in command_type_str.lower():
            command_type_str = 'MxRegisteredCmdType.MX_REGISTERED_CMD_TYPE_CONTROLLING'

        # Read the template file
        template_source = ""
        with importlib.resources.files(__package__).joinpath(msb.mxpy_template_filename).open("r",
                                                                                              encoding='utf-8') as f:
            template_source = f.read()

        # Get the program name (file name without extension)
        script_name = pathlib.Path(script_file_path).stem

        # Perform replacements in the template file
        indented_source = textwrap.indent(script_source, '    ')
        final_source = template_source
        final_source = final_source.replace('###ScriptName###', script_name)
        final_source = final_source.replace('###ScriptDescription###', script_description)
        final_source = final_source.replace('###ScriptCyclicId###', "None" if cyclic_id is None else f'{cyclic_id}')
        final_source = final_source.replace('###ScriptCmdType###', command_type_str)
        final_source = final_source.replace('###ScriptCode###', indented_source)

        return final_source

    def _load_module(self):
        """This function imports the module from the source code file.
        It can optionally insert a "import" directive for sidecar_script_base, which allow writing very simple
        programs that don't explicit import directive on top
        """
        tmp_file_path: str = None
        try:
            # Determine if we need to apply the mxpy template
            use_template = (self.module_path is not None and self.module_path.endswith(msb.mxpy_suffix))

            if use_template:
                if not os.path.exists(self.module_path):
                    raise FileNotFoundError(f'Cannot find module file {self.module_path}')

                # Load the program, wrapped into template module code
                module_source = self.load_mxpy_from_template(self.module_path)
                tmp_file_path = self.module_path.replace(msb.mxpy_suffix, msb.mxpy_prepended_suffix)
                with open(tmp_file_path, 'w', encoding='utf-8') as f:
                    f.write(module_source)

                load_path = tmp_file_path

            else:
                # Load directly from module_path if specified, else fallback to import by name
                load_path = self.module_path

            # Determine the module name
            module_name = (self.module_path_to_name(load_path) if load_path else self.module_name)

            reload_module = module_name in sys.modules
            if load_path and os.path.exists(load_path):
                # Import from path using importlib.util
                spec = importlib.util.spec_from_file_location(module_name, load_path)
                module = importlib.util.module_from_spec(spec)
                sys.modules[module_name] = module
                spec.loader.exec_module(module)
            else:
                # Standard import (module must be importable by name)
                module = importlib.import_module(module_name)
                if reload_module:
                    module = importlib.reload(module)

            self.module = module

        finally:
            # Clean up temporary file
            if tmp_file_path and os.path.exists(tmp_file_path):
                os.unlink(tmp_file_path)


class MecaScriptLoader(PythonModuleLoader):
    """
    This class is a specialization of PythonModuleLoader that loads sidecar MecaScripts and instantiates the
    class that it defines.
    As MecaScript class is being instantiated, the "on_register" method is called.
    The "on_unregister" method is called before reloading or unloading the MecaScript.

    """

    def __init__(self,
                 robot: RobotSideCar,
                 mecascript_path: str,
                 mecascript_type: mecascript.MecaScriptType,
                 template_line_offset: Optional[int] = 0,
                 debug: Optional[bool] = False):
        """ Initialize this MecaScript management class """
        self._mecascript_instance: Optional[msb.MecaScriptBase] = None
        self._mecascript_type = mecascript_type
        super().__init__(
            robot,
            module_path=mecascript_path,
            monitor_file=not robot.embedded,
            template_line_offset=template_line_offset if mecascript_type == mecascript.MecaScriptType.MXPY else 0,
            debug=debug)

        # Current program status
        self.program_status = mdr.MxProgramStatus.MX_PROGRAM_UNLOADED
        self.load_error_msg = ""

        # Callback called when file status changed
        self.fct_update_meca_script_status: Optional[Callable[[str, mdr.MxProgramStatus, str]]] = None

    def __del__(self):
        self.unregister()

    def load(self):
        # Load this MecaScript from the source file on disk.
        # Then create the MecaScript instance and call it's "on_register" method
        if self._mecascript_instance is not None:
            self.unregister()
            self._update_program_status(mdr.MxProgramStatus.MX_PROGRAM_RELOADING)
        else:
            self._update_program_status(mdr.MxProgramStatus.MX_PROGRAM_LOADING)

        try:
            super().load()
        # pylint: disable=broad-exception-caught
        except Exception as e:
            # Note: No need to MecaScriptLogTrace here, load() above already did it
            self._update_program_status(mdr.MxProgramStatus.MX_PROGRAM_FAILED_TO_LOAD, message=f'{e}')
            # Note: No need to re-raise the error, error is handled properly (load error status set)
            # raise e
            return

        try:
            self._register_mecascript()
            self._update_program_status(mdr.MxProgramStatus.MX_PROGRAM_LOADED)
        except FileNotFoundError as e:
            self.robot.MecaScriptLogTrace(f"Module '{self.module_path}' file not found: {e}",
                                          level=logging.ERROR,
                                          trace_id=mdr.MxUserTrace.MX_USER_TRACE_SIDE_CAR_ERROR)
            self._update_program_status(mdr.MxProgramStatus.MX_PROGRAM_NOT_FOUND)
            # Note: No need to re-raise the error, error is handled properly (load error status set)
            # raise e
            return
        except Exception as e:  # pylint: disable=broad-exception-caught
            message = f"Failed to load module '{self.module_path}': {e}"
            self.robot.MecaScriptLogTrace(message,
                                          level=logging.ERROR,
                                          trace_id=mdr.MxUserTrace.MX_USER_TRACE_SIDE_CAR_ERROR)
            stack_str = format_mecascript_stack_str(e, debug=self.debug)
            if stack_str != '':
                self.robot.MecaScriptLogTrace(f'Exception trace:\n{stack_str}',
                                              level=logging.ERROR,
                                              trace_id=mdr.MxUserTrace.MX_USER_TRACE_SIDE_CAR_ERROR)

            self._update_program_status(mdr.MxProgramStatus.MX_PROGRAM_FAILED_TO_LOAD, message=message)
            # Note: No need to re-raise the error, error is handled properly (load error status set)
            # raise e
            return

    def _create_mecascript_instance(self, module: types.ModuleType) -> Any:
        """Create the user's MecaScript class by searching in the module for a class derived from MecaScriptBase.
        Then returns an instance of that class.
        Note that the __init__ function does nothing in our base class, we'll call necessary initialization afterwards.

        Args:
            module (types.ModuleType): The user MecaScript that we just loaded from disk

        Raises:
            mdr.NotFoundException: When the user module does not define a class that derives from MecaScriptBase

        Returns:
            Any: An instance of user's class that derives from MecaScriptBase
        """
        for _, obj in inspect.getmembers(module, inspect.isclass):
            if issubclass(obj, msb.MecaScriptBase) and obj is not msb.MecaScriptBase:
                return obj()  # Instantiate it
        raise mdr.NotFoundException(f'Could not find a class that derives from MecaScriptBase')

    def _register_mecascript(self):
        """ Create a MecaScript instance, then call its on_register method """

        self._mecascript_instance = self._create_mecascript_instance(self.module)
        if self._mecascript_instance is not None:
            # Now finish module initialization
            # pylint: disable=protected-access
            self._mecascript_instance._init_mecascript(file_path=self.module_path,
                                                       mecascript_type=self._mecascript_type,
                                                       robot=self.robot)
            # Call user's on_register method
            self._mecascript_instance.on_register()

    def unregister(self):
        """ Unregister this MecaScript.
        Note that unloading a python module is impossible, but at least this function will call MecaScript's
        on_unregister
        """
        if self._mecascript_instance is not None:
            self._update_program_status(mdr.MxProgramStatus.MX_PROGRAM_UNLOADING)
            # Call user's on_unregister method
            self._mecascript_instance.on_unregister()
            # Finish module termination
            self._mecascript_instance._term_mecascript()  # pylint: disable=protected-access
        self._update_program_status(mdr.MxProgramStatus.MX_PROGRAM_UNLOADED)
        self._mecascript_instance = None
        self.loaded_cfg = False
        self.loaded = False
        self.reload_pending = False

    def is_unregistered(self) -> bool:
        """Returns if the module is unregistered or not """
        return self._mecascript_instance is None

    def get_registered_commands(self) -> list[str]:
        """ Get the list of commands that are registered by this MecaScript """
        registered_commands: list[str] = []
        if self._mecascript_instance:
            command_list = self.robot.mecascript_get_registered_commands(self._mecascript_instance.get_module_name())
            for _, command_name in command_list:
                registered_commands += command_name
        return registered_commands

    def _update_program_status(self, program_status: mdr.MxProgramStatus, message: Optional[str] = ""):
        """Update current program status"""
        if self.program_status != program_status or self.load_error_msg != message:
            self.program_status = program_status
            self.load_error_msg = message

            # Notify robot with callback if any
            if self.fct_update_meca_script_status is not None:
                self.fct_update_meca_script_status(self.module_path if self.module_path else "", program_status,
                                                   message)


class MecaScriptLauncher:
    """ This class defines a sidecar launcher that is responsible to launch MecaScripts and attach to the robot
        for receiving requests to call sidecar registered commands """

    def __init__(self, robot: RobotSideCar, robot_ip: str, embedded=False, debug=False):
        """Constructor for this class

        Args:
            robot (RobotSideCar): The robot object to use with this sidecar.
                                  Note that this object shall not yet be connected to the robot. This launcher will
                                  choose when and how to connect to the robot.
            embedded (bool): True if running embedded in the robot, False otherwise
            debug (bool): True to enable debug mode (more verbose stack traces and possibly other error traces)
        """
        self.logger = logging.getLogger(__name__)
        self.robot = robot
        self.robot_ip = robot_ip
        self.embedded = embedded
        self.debug = debug
        self._quit_requested = False
        self._garbage_collect_pending = False
        self._garbage_collect_running = False
        self._garbage_collect_last_run = 0
        self.sidecar_status = mecascript.SidecarInternalStatus()

        # Create a message queue to receive sidecar requests from the robot
        self._msg_queue = queue.Queue()

        # Define our message handlers for all messages that we expect to receive from the robot
        self._messages_handlers = {
            mdr.MxRobotStatusCode.MX_ST_SIDECAR_CMD_EXEC:  # 3202
            self._handle_sidecar_cmd_exec,
            mdr.MxRobotStatusCode.MX_ST_UPDATE_LOADED_PROGRAMS:  # 3221
            self._handle_sidecar_loaded_programs,
            mdr.MxRobotStatusCode.MX_ST_SIDECAR_SAVED_PYTHON_FILE:  # 3223
            self._handle_sidecar_saved_python_file,
        }

        self._register_done = False  # Tells if we've confirmed to the robot we finished registering commands
        self._mecascript_paths_known = False  # Tells if we know what MecaScripts we must load
        self._mecascript_paths: list[str] = []  # All MecaScripts that we expect to be loaded
        self._mecascript_paths_to_reload: list[str] = []  # Scripts that are loaded but must be reloaded
        self._mecascripts: list[MecaScriptLoader] = []  # MecaScripts currently loaded
        self._watchdog_poll_time = 0

        self._template_line_offset = self._find_template_offset()

        self._mecascript_executor = PythonModuleLoader(self.robot, module_name="mecascript.executor", debug=self.debug)

    def register_to_robot(self):
        """Register ourself to the robot to indicate that we will handle its sidecar messages """
        self.robot.mecascript_register_msg_queue(self._msg_queue)

    def unregister_from_robot(self):
        """Unregister ourself from the robot to indicate that we will handle its sidecar messages """
        self.poll(enabled=False)
        self.robot.mecascript_register_msg_queue(None)

    #####################################################################################
    # Public methods
    #####################################################################################

    def set_local_mecascripts(self, mecascript_paths: list[str]):
        """Set the list of MecaScripts that must be loaded by this sidecar.
        These MecaScripts will be loaded once connected to the robot (possibly immediately if already connected).

        If this function is called while some MecaScripts are already loaded, all programs passed in argument will be
        force reloaded

        Args:
            mecascript_paths (list[str]): List of MecaScript paths to load/execute
        """
        # Keep new mecascripts list
        self._mecascript_paths = mecascript_paths

        self._mecascript_paths_known = True

        if self.robot.IsConnected():
            # Immediately apply changes
            self._load_unload_mecascripts()

    def quit(self):
        """ Indicate that we must quit (interrupt what we're doing)"""
        self._quit_requested = True

    def reload_modified_mecascripts(self) -> bool:
        """ Reload MecaScripts that have been modified (by checking their modification dates)
        Returns:
            bool: True if some MecaScripts were reloaded
        """
        changes_found = False
        for mecascript_file in self._mecascripts:
            if not mecascript_file.monitor_file:
                continue

            changed = mecascript_file.is_changed()
            if changed:
                changes_found = True
                # Reload and re-run the mecascript
                try:
                    mecascript_file.load()
                # pylint: disable=broad-exception-caught
                except Exception as e:
                    stack_str = format_mecascript_stack_str(e, debug=self.debug)
                    if stack_str == '':
                        self.logger.error(f'Failed to reload mecascript: {e}')
                    else:
                        self.logger.error(f'Failed to reload mecascript: {e}:\n{stack_str}')

        return changes_found

    def _register_sidecar_sync(self):
        """ Register the SidecarSync built-in command.
        This only does something for an embedded sidecar engine because in this case the robot may ask to load/unload
        programs at run time and may want to ensure that the loading/unloading operation has completed before it
        processes more API commands from the user that saved/modified/deleted some program.
        """
        if not self.embedded:
            # Nothing to do, only the embedded sidecar engine registers the SidecarSync command
            return

        if self.robot.mecascript_get_registered_command(mecascript.MX_SIDECAR_SYNC_CMD_NAME) is not None:
            # Already registered
            self.logger.error(f'_register_sidecar_sync called twice, this should not happen')

        # pylint: disable=unused-argument
        def sidecar_sync(*args, **kwargs):
            # Add user trace only for not internal request
            self.robot.logger.log(logging.DEBUG, f'{mecascript.MX_SIDECAR_SYNC_CMD_NAME} executing')

        sync_command = mecascript.RegisteredCommand(
            function=sidecar_sync,
            name=mecascript.MX_SIDECAR_SYNC_CMD_NAME,
            description=("This command is used to make sure that the sidecar engine has finished executing "
                         "previous commands calls or mecascripts loading instructions."),
            tags=[mecascript.MX_CMD_TAG_SIDECAR],
            cyclic_id=mecascript.MX_MOTION_CMD_SIDECAR_SYNC)
        self.robot.mecascript_register_command(sync_command)

    def _unregister_sidecar_sync(self):
        """ Unregister the SidecarSync built-in command """
        if not self.embedded:
            # Nothing to do, only the embedded sidecar engine registers the SidecarSync command
            return
        self.robot.mecascript_unregister_command(mecascript.MX_SIDECAR_SYNC_CMD_NAME)

    def check_robot_connection(self):
        """ Connect to the robot if not already done """
        was_connected = self.robot.IsConnected()
        if not was_connected:
            # Make sure to unload mecascripts
            self._load_unload_mecascripts()

            # Wait some delay before trying to connect
            if not self._quit_requested:
                # Try connecting
                try:
                    self.robot.ConnectAsSidecar(address=f'{self.robot_ip}:{mdr.MX_ROBOT_TCP_PORT_CONTROL_JSON}')

                    # Register the sidecar built-in "SidecarSync" command
                    self._register_sidecar_sync()

                    # Start polling (this enables the connection watchdog)
                    self.poll()

                    # Send our initial state to he robot
                    # pylint: disable=protected-access
                    self.robot._mecascript_push_status_to_robot(self.sidecar_status)
                except (mdr.CommunicationError, ConnectionError, TimeoutError):
                    # Sleep before retrying later
                    def interrupted_callback(_: float) -> bool:
                        return self._quit_requested

                    interruptable_sleep(5, condition_callback=interrupted_callback)

        # Check if mecascripts need to be loaded or unloaded
        self._load_unload_mecascripts()

    def wait_message(self, timeout: float) -> Optional[mdr.Message]:
        """Wait for the next message to process, or timeout

        Args:
            timeout (float): Maximum time to wait for a message

        Returns:
            Optional[mdr.Message]: The received message, or None
        """
        # Check if we can reconnect with the robot
        self.check_robot_connection()

        # Refresh the connection watchdog
        self.poll()

        if self._garbage_collect_pending and not self._garbage_collect_running:
            threading.Thread(target=self.trim_heap, daemon=True).start()

        # Read next sidecar message from the robot
        message: mdr.Message = None
        try:
            message = self._msg_queue.get(block=True, timeout=timeout)
        except queue.Empty:
            pass
        return message

    def handle_message(self, message: mdr.Message) -> bool:
        """Handle a received message

        Args:
            message (mdr.Message): The received message to handle

        Returns:
            bool: True if the message was handled, False otherwise
        """
        handled = False
        callback = self._messages_handlers.get(message.id)
        if callback:
            callback(message)
            handled = True
        return handled

    def trim_heap(self):
        """Trim HEAP usage (call Python's garbage collector, and glibc trim) to ensure that freed memory is
           returned to the kernel and no longer calculated against maximum memory usage for MecaScript (200MB)
        """
        # Run only once in a while
        now = time.monotonic()
        elapsed = now - self._garbage_collect_last_run
        if elapsed < MX_SIDECAR_HEAP_TRIM_MIN_INTERVAL_SEC:
            return
        self._garbage_collect_last_run = now

        self._garbage_collect_running = True
        self._garbage_collect_pending = False
        try:
            gc.collect()
            if platform.system() != 'Windows':
                ctypes.CDLL("libc.so.6").malloc_trim(0)
        except Exception as e:  # pylint: disable=broad-exception-caught
            self.robot.LogTrace(f'Exception during heap trim: {e}', level=logging.ERROR)
        finally:
            self._garbage_collect_running = False
            elapsed = time.monotonic() - now

    def poll(self, enabled=True):
        """ Refreshes the sidecar connection watchdog (with the default sidecar timeout:
        MX_SIDECAR_CONNECTION_TIMEOUT_SEC)"""
        try:
            if enabled:
                call_now = True
                now = time.monotonic()
                if self._watchdog_poll_time != 0:
                    elapsed = now - self._watchdog_poll_time
                    if elapsed < mdr.MX_SIDECAR_CONNECTION_TIMEOUT_SEC / 4:
                        call_now = False
                if call_now:
                    self.robot.ConnectionWatchdog(timeout=mdr.MX_SIDECAR_CONNECTION_TIMEOUT_SEC,
                                                  message='Sidecar launcher periodic polling')
                    self._watchdog_poll_time = now
            else:
                self.robot.ConnectionWatchdog(0)
        except (mdr.InvalidStateError, mdr.DisconnectError):
            # This will occur if the connection has timed-out while executing the command.
            # If it happens, self.robot will be disconnected, but here we continue. We'll retry connecting later.
            pass

    def call_command(self, command_name: str, *args, **kwargs):
        """Call a sidecar registered command by name"""
        # pylint: disable=protected-access
        self.robot._set_executing_sidecar_command(executing=True, raw_code_file_name=None)
        self.robot.mecascript_call_registered_command(command_name, *args, **kwargs)

    def execute_raw_code(self, raw_code: str, file_name: str, first_line_idx: int):
        """Execute raw Python code as if it was from a .mxpy MecaScript.
           This is used by the MecaPortal when it's asked to execute code from the code editor.
        """
        # pylint: disable=protected-access
        self.robot._set_executing_sidecar_command(executing=True, raw_code_file_name=file_name)
        self._mecascript_executor.module.exec_mecascript_code(raw_code, first_line_idx)

    def call_command_cleanup(self, command_name: str):
        """Cleanup that must be called after call_command

        Args:
            command_name (str): Name of the command that was called
        """
        self._garbage_collect_pending = True
        # pylint: disable=protected-access
        self.robot._mecascript_set_can_continue(False, False)
        self.robot._set_executing_sidecar_command(False)
        # Restore asynchronous mode (default mode when sidecar is running)
        self.robot.SetSynchronousMode(False)
        try:
            # Stop automatic polling (take back control of polling with timeout MX_SIDECAR_CONNECTION_TIMEOUT_SEC)
            self.robot.AutoConnectionWatchdog(False,
                                              timeout=mdr.MX_SIDECAR_CONNECTION_TIMEOUT_SEC,
                                              message=f'Finished running {command_name}')
            # Notify the robot that the command execution has completed
            self.robot.send_sidecar_exec_done(command_name)
        except mdr.MecademicNonFatalException:
            # This happens if we get disconnected from the robot, let's ignore and continue with launcher code
            pass

    #####################################################################################
    # Private methods
    #####################################################################################
    def _update_loaded_program_status(self, module_path: str, program_status: mdr.MxProgramStatus, message: str):
        """ Update sidecar loaded program status """

        if program_status == mdr.MxProgramStatus.MX_PROGRAM_UNLOADED:
            # Let's completely remove unloaded programs from the status. In fact, since in Python there is no way to
            # really unload a module, we're force to also keep the module forever in self._modules to know that we
            # must reload it (and not just load it) when necessary later.
            # But we don't want to report status for a program that possibly no longer exists on disk and in the
            # MecaPortal user files list.
            if module_path in self.sidecar_status.loaded_programs_status:
                del self.sidecar_status.loaded_programs_status[module_path]
        else:
            self.sidecar_status.loaded_programs_status[module_path] = {
                mdr.MX_JSON_KEY_LOADED_PROGRAM_STATUS: program_status,
                mdr.MX_JSON_KEY_LOADED_PROGRAM_MESSAGE: message
            }
        # pylint: disable=protected-access
        self.robot._mecascript_push_status_to_robot(self.sidecar_status)

    def _load_executor(self):
        """ Load the mecascript executor (responsible to run MecaScript code line by line) """
        # Also reload the mecascript executor so it can access the newly registered global commands/variables from
        # the newly loaded mecascripts
        try:
            self._mecascript_executor.load()
            self._mecascript_executor.module.initialize_globals()
        # pylint: disable=broad-exception-caught
        except Exception as e:
            stack_str = format_mecascript_stack_str(e, debug=self.debug)
            if stack_str == '':
                self.logger.error(f'Failed to load mecascript executor: {e}')
            else:
                self.logger.error(f'Failed to load mecascript executor: {e}:\n{stack_str}')

    def _load_unload_mecascripts(self):
        """Load or unload all MecaScripts depending if we're connected to the robot or not
        """

        if self.robot.IsConnected():
            # Unload all MecaScripts that should not be running anymore
            for mecascript_file in self._mecascripts:
                must_still_run = False
                for mecascript_path in self._mecascript_paths:
                    if mecascript_file.module_path == mecascript_path:
                        must_still_run = True
                        break
                if not must_still_run and mecascript_file.loaded:
                    self.poll()
                    mecascript_file.unregister()

            # Reload MecaScripts that we need to reload
            for mecascript_path in self._mecascript_paths_to_reload:
                mecascript_file = self._find_mecascript_by_path(mecascript_path)
                if mecascript_file is not None:
                    try:
                        self.poll()
                        mecascript_file.load()
                    # pylint: disable=broad-exception-caught
                    except Exception as e:
                        stack_str = format_mecascript_stack_str(e, debug=self.debug)
                        if stack_str == '':
                            self.logger.error(f'Failed to reload MecaScript: {e}')
                        else:
                            self.logger.error(f'Failed to reload MecaScript: {e}:\n{stack_str}')
            self._mecascript_paths_to_reload = []

            # Load new MecaScripts that were not loaded yet
            for mecascript_path in self._mecascript_paths:
                mecascript_file = self._find_mecascript_by_path(mecascript_path)
                load_now = (mecascript_file is None
                            or mecascript_file.program_status == mdr.MxProgramStatus.MX_PROGRAM_UNLOADED)
                if mecascript_file is None:
                    # Create a new MecaScript instance and add it to our list
                    try:
                        is_mxpy = (mecascript_path is not None and mecascript_path.endswith(msb.mxpy_suffix))
                        if is_mxpy:
                            mecascript_type = mecascript.MecaScriptType.MXPY
                        else:
                            mecascript_type = mecascript.MecaScriptType.PY
                        mecascript_file = MecaScriptLoader(self.robot,
                                                           mecascript_path,
                                                           mecascript_type,
                                                           self._template_line_offset,
                                                           debug=self.debug)
                        mecascript_file.fct_update_meca_script_status = self._update_loaded_program_status

                        self._mecascripts.append(mecascript_file)
                        load_now = True
                    # pylint: disable=broad-exception-caught
                    except Exception as e:
                        stack_str = format_mecascript_stack_str(e, debug=self.debug)
                        if stack_str == '':
                            self.logger.error(f'Failed to create MecaScript loader: {e}')
                        else:
                            self.logger.error(f'Failed to create MecaScript loader: {e}:\n{stack_str}')
                        load_now = False
                elif mecascript_file.reload_pending:
                    load_now = True
                if load_now:
                    # Load/reload the Mecascript
                    try:
                        self.poll()
                        mecascript_file.load()
                    # pylint: disable=broad-exception-caught
                    except Exception as e:
                        # No need to print error, mecascript.load() already did it
                        pass
                    if not self.robot.IsConnected():
                        break

            if self._mecascript_executor.module is None:
                self.poll()
                self._load_executor()

            if self._mecascript_paths_known and not self._register_done:
                # Notify the robot that we're done loading/registering the MecaScripts/commands
                self._register_done = True
                self.robot.mecascript_register_done()
                self.poll()

        else:  # Not connected to the robot
            if self.robot.mecascript_get_registered_command(mecascript.MX_SIDECAR_SYNC_CMD_NAME) is not None:
                self._unregister_sidecar_sync()
            self._register_done = False
            # Unload all MecaScripts
            if len(self._mecascripts) != 0:
                for mecascript_file in self._mecascripts:
                    mecascript_file.unregister()
                # Note: Do not remove module from self._mecascripts even after unregistering it. A Python module
                #       can never really be unloaded. So let's keep the module object in our list (in state "unloaded")
                #       so the next time we're ask to load it we know it must be "reloaded" from disk
                #       (see PythonModuleLoader -> _load_module, flag reload_module)
                #self._mecascripts.clear()
                self.sidecar_status.loaded_programs_status.clear()

            if self.embedded:
                # We're running inside the robot, in that case the list of MecaScripts to load is received from
                # the robot. We must "forget" our list for now.
                self._mecascript_paths_known = False
                self._mecascript_paths = []

    def _find_template_offset(self) -> int:
        """ Find the offset of the user .mxpy program code when inserted in the template file """
        template_offset = 0
        with importlib.resources.files(__package__).joinpath(msb.mxpy_template_filename).open("r",
                                                                                              encoding='utf-8') as file:
            # Iterate through each line with its line number
            for line_number, line in enumerate(file, start=1):
                # Check if the line contains the target string
                if '###ScriptCode###' in line:
                    template_offset = line_number - 1
                    break
        return template_offset

    def _find_mecascript_by_path(self, mecascript_path: str) -> Optional[MecaScriptLoader]:
        """Find the loaded MecaScript by path

        Args:
            mecascript_path (str): Mecascript path to find

        Returns:
            Optional[MecaScriptLoader]: Found MecaScript, or None if not currently loaded
        """
        for mecascript_file in self._mecascripts:
            if mecascript_file.module_path == mecascript_path:
                return mecascript_file
        return None

    def _handle_sidecar_cmd_exec(self, message: mdr.Message):
        """ Handle message of type MX_ST_SIDECAR_CMD_EXEC """
        # Sanity check
        if not message.json_data:
            raise mdr.ArgErrorException(f'Expected JSON format for MX_ST_SIDECAR_CMD_EXEC')

        #json_metadata: dict = message.json_data[mdr.MX_JSON_KEY_META_DATA]  # pylint: disable=unused-variable

        json_data: dict = message.json_data[mdr.MX_JSON_KEY_DATA]

        command_name: str = json_data.get(mdr.MX_JSON_KEY_SIDECAR_CMD_EXEC_NAME, "")
        args = json_data.get(mdr.MX_JSON_KEY_SIDECAR_CMD_EXEC_ARGS, [])
        kwargs = json_data.get(mdr.MX_JSON_KEY_SIDECAR_CMD_EXEC_KWARGS, {})
        raw_code: Optional[str] = json_data.get(mdr.MX_JSON_KEY_SIDECAR_CMD_EXEC_RAW, None)
        file_name: str = json_data.get(mdr.MX_JSON_KEY_SIDECAR_CMD_EXEC_FILE, "")
        first_line_idx: int = json_data.get(mdr.MX_JSON_KEY_SIDECAR_CMD_EXEC_LINE, 0)
        command_type: Optional[mdr.MxRegisteredCmdType] = None
        if mdr.MX_JSON_KEY_SIDECAR_CMD_EXEC_TYPE in json_data:
            command_type = mdr.MxRegisteredCmdType(json_data[mdr.MX_JSON_KEY_SIDECAR_CMD_EXEC_TYPE])

        command = self.robot.mecascript_get_registered_command(command_name)
        controlling = (command is not None
                       and command.command_type == mecascript.MxRegisteredCmdType.MX_REGISTERED_CMD_TYPE_CONTROLLING)

        if raw_code:
            self.robot.ConnectionWatchdog(timeout=mdr.MX_SIDECAR_CONNECTION_TIMEOUT_SEC,
                                          message=f'Executing raw code from {file_name}')
            if command_type != mdr.MxRegisteredCmdType.MX_REGISTERED_CMD_TYPE_INLINE:
                self.robot.AutoConnectionWatchdog(True)
        elif controlling:
            # Start the automatic connection watchdog while the "controlling" command is executed (so customer code
            # does not have to know about that)
            self.robot.ConnectionWatchdog(timeout=mdr.MX_SIDECAR_CONNECTION_TIMEOUT_SEC,
                                          message=f'Calling sidecar controlling command {command_name}')
            self.robot.AutoConnectionWatchdog(True)
        else:
            self.robot.ConnectionWatchdog(timeout=mdr.MX_SIDECAR_CONNECTION_TIMEOUT_SEC,
                                          message=f'Calling sidecar inline command {command_name}')

        line_offset = 0
        if command is not None and command.mecascript_type == mecascript.MecaScriptType.MXPY:
            line_offset = self._template_line_offset
        err_message = ""
        exception: Optional[Exception] = None

        try:
            # pylint: disable=protected-access
            # Send an last explicit poll to reset the allowed time for the command and also notify the robot
            # of what we're doing now
            self.robot._mecascript_set_can_continue(True, True)
            self.robot.SetStopProgramInterruption(True)  # By default, programs are interrupted upon StopProgram
            if raw_code is not None:
                nb_lines = raw_code.count('\n')
                self.robot.MecaScriptLogTrace(
                    f'Executing raw code from {file_name} (length {len(raw_code)} for {nb_lines} lines)')
                self.execute_raw_code(raw_code, file_name, first_line_idx)
            else:
                self.call_command(command_name, *args, **kwargs)
        except mdr.StopProgramException as e:
            self.robot.MecaScriptLogTrace(f'{e} Script aborted (StopProgramException not caught by {command_name})')
        # pylint: disable=broad-exception-caught
        except SyntaxError as e:
            exception = e
            e.lineno -= line_offset
            if raw_code is not None:
                err_message = f'Exception raised in executed code at line {e.lineno}: {e.msg}'
            else:
                err_message = f'Exception raised in {e.filename} at line {e.lineno}: {e.msg}'
        except Exception as e:
            exception = e
            extracted_trace = traceback.extract_tb(e.__traceback__)
            # Find the first non-internal code from the top of call stack (the last user code that was
            # executing before calling an internal function from within which the exception occurred)
            idx = len(extracted_trace) - 1
            while idx > -1:
                if not is_internal_file(extracted_trace[idx].filename):
                    break
                idx = idx - 1

            if idx < 0 and raw_code:
                # No "user code" was found, meaning that the only thing that was executed here is the raw code
                # itself. Let's find the file/line in that raw code
                idx = len(extracted_trace) - 1
                while idx > -1:
                    if 'exec_mecascript_code' in extracted_trace[idx].name:
                        idx = idx + 1  # Move up to customer code called by exec_mecascript_code
                        break
                    idx = idx - 1

            if idx >= 0:
                _, lineno, func_name, _ = extracted_trace[idx]
            else:
                lineno = 0
                func_name = ""
            if lineno > line_offset:
                lineno -= line_offset
            at_line = f' at line {lineno}' if lineno > 0 else ''
            if raw_code is not None:
                err_message = f'Exception raised in executed code{at_line}: {e}'
            elif Path(command.file_path).stem.endswith(func_name):
                err_message = f'Exception raised in {command.file_path}{at_line}: {e}'
            else:
                # This is a registered command
                err_message = f'Exception raised in {command.file_path}{at_line} (command {func_name}): {e}'

        finally:
            try:
                if err_message != "":
                    self.robot.logger.error(err_message)

                    if self.robot.IsConnected():
                        self.robot.SetStopProgramInterruption(False)  # Disable interruption so we can force error
                        self.robot.force_error(err_message)

                    #  Print call stack too
                    stack_str = format_mecascript_stack_str(exception,
                                                            format_callback=self._fix_prepended_line_number,
                                                            debug=self.debug)
                    if stack_str != '':
                        self.robot.MecaScriptLogTrace(f'Exception trace:\n{stack_str}',
                                                      level=logging.ERROR,
                                                      trace_id=mdr.MxUserTrace.MX_USER_TRACE_SIDE_CAR_ERROR)
            finally:
                self.call_command_cleanup(command_name)

    def _handle_sidecar_loaded_programs(self, message: mdr.Message):
        """Handle load/reload/unload programs """
        if not self.embedded:
            # We're running separately from the robot, let's ignore MecaScripts from the robot
            self.robot.LogTrace(f'Ignoring robot MecaScripts (sidecar is running standalone)')
            return
        if message.json_data:
            json_data: dict = message.json_data.get(mdr.MX_JSON_KEY_DATA, {})
            loaded_programs = json_data.get(mdr.MX_JSON_KEY_LOADED_PROGRAMS_FILES, "")

            for program in loaded_programs:
                program_name = program.get(mdr.MX_JSON_KEY_LOADED_PROGRAM_NAME, "")
                program_loaded = program.get(mdr.MX_JSON_KEY_LOADED_PROGRAM_LOADED_CFG, "")

                if program_loaded:
                    if program_name in self._mecascript_paths:
                        # Already loaded, must reload
                        self._mecascript_paths_to_reload.append(program_name)
                    else:
                        # Add to list of programs that should be loaded
                        self._mecascript_paths.append(program_name)
                    # Note: even if we did not find the program in self._mecascript_paths, it's still possible that
                    #       we still have a loaded module object in self._mecascripts (because a script that was
                    #       loaded once then unloaded remains in self._mecascripts since in Python there is no way
                    #       to really unload a module).
                    #       Let's set reload_pending flag in this case to force a reload
                    mecascript_file = self._find_mecascript_by_path(program_name)
                    if mecascript_file is not None:
                        mecascript_file.reload_pending = True
                elif program_name in self._mecascript_paths:
                    # Make sure that the program is not in the list of programs to execute
                    self._mecascript_paths.remove(program_name)

        self._mecascript_paths_known = True

        if self.robot.IsConnected():
            # Immediately apply changes
            self._load_unload_mecascripts()

    def _is_imported(self, importers: list[str], file_path: str) -> bool:
        """Tells if the specified Python file is imported (directly or indirectly) by a loaded MecaScript.

        Args:
            importers (list[str]): List of already found importers for this file
            file_path (str): File to check if imported

        Returns:
            bool: True if file_path is used by an active MecaScript
        """
        # Build a list of files that imported file_path
        new_importers: list[str] = []
        for importer_path, dependencies in g_module_dependencies.items():
            if file_path in dependencies:
                if importer_path not in importers:
                    new_importers.append(importer_path)

        # Check if one of these new importers is an active MecaScript
        for new_importer in new_importers:
            mecascript_file = self._find_mecascript_by_path(new_importer)
            if mecascript_file is not None and mecascript_file.loaded_cfg:
                return True

        # Append to list of importers (so we reload them once, and avoid infinite recursion)
        importers += new_importers

        # Some importers may themselves be imported by other files, so let's recurse
        for new_importer in new_importers:
            is_imported = self._is_imported(importers, new_importer)
            if is_imported:
                return True

        return False

    def _reload_importers_recurs(self, importers: list[str], file_path: str):
        """ Recursively reload all Python files that are importing the module (file_path).
        Plain Python files are reloaded immediately.
        Loaded MecaScripts are added to _mecascript_paths_to_reload and are reloaded later by _load_unload_mecascripts
        """
        # Build a list of files that imported file_path
        new_importers: list[str] = []
        for importer_path, dependencies in g_module_dependencies.items():
            if file_path in dependencies:
                if importer_path not in importers:
                    new_importers.append(importer_path)

        # Reload all files that imported file_path, so then are now using the new version of that file
        for new_importer in new_importers:
            module_name = PythonModuleLoader.module_path_to_name(new_importer)
            if new_importer in self._mecascript_paths:
                # This is a "loaded" MecaScript, we'll reload it later
                self.robot.LogTrace(f'Will reload MecaScript {new_importer} (child import {file_path} modified)')
                self._mecascript_paths_to_reload.append(new_importer)
            else:
                # This is not a "loaded" MecaScript, it's thus a plain Python file to reload
                try:
                    self.robot.LogTrace(f'Reloading {new_importer} (child import {file_path} modified)')
                    loader = PythonModuleLoader(self.robot, module_name, debug=self.debug)
                    loader.load()
                #pylint: disable=broad-exception-caught
                except Exception as e:
                    # Log the error, then continue trying to load others
                    self.logger.error(f'Failed to reload {module_name}: {e}')

        # Append to list of importers (so we reload them once, and avoid infinite recursion)
        importers += new_importers

        # Some importers may themselves be imported by other files, so let's recurse
        for new_importer in new_importers:
            self._reload_importers_recurs(importers, new_importer)

    def _handle_sidecar_saved_python_file(self, message: mdr.Message):
        """Handle saved Python file.
        The robot sends this message when a Python file (that is not a "loaded" MecaScript) has been saved.
        Here we check if this file has been "imported" by one of the "loaded" MecaScripts.
        If it is, we will force reload this file, and the referring MecaScripts
        """
        # Sanity check
        if not message.json_data:
            raise mdr.ArgErrorException(f'Expected JSON format for MX_ST_SIDECAR_SAVED_PYTHON_FILE')

        json_data: dict = message.json_data.get(mdr.MX_JSON_KEY_DATA, {})
        python_file_path = json_data.get(mdr.MX_JSON_KEY_LOADED_PROGRAM_NAME, None)
        if python_file_path is None:
            return

        # Reload only if module is referenced by one of our active (loaded) programs
        module_name = PythonModuleLoader.module_path_to_name(python_file_path)
        if not self._is_imported([], python_file_path):
            # This file is not referenced by anyone. Instead of reloading it, we can remove it from sys.modules
            # which will force a reload from disk the next time it's referenced
            if module_name in sys.modules:
                self.robot.LogTrace(f'Python file {python_file_path} modified, but no more used. Unloading it.')
                del sys.modules[module_name]
        else:
            # One of our programs imports this file, so let's reload it, then reload the programs importing it
            self.robot.LogTrace(f'Python file {python_file_path} modified. Will reload all dependencies.')
            try:
                loader = PythonModuleLoader(self.robot, module_name, debug=self.debug)
                loader.load()
            #pylint: disable=broad-exception-caught
            except Exception as e:
                # Log the error, then continue trying to load others
                self.logger.error(f'Failed to reload {module_name}: {e}')
                if module_name in sys.modules:
                    del sys.modules[module_name]
            # Find all modules that depend on this file
            importers: list[str] = []
            self._reload_importers_recurs(importers, python_file_path)

    def _fix_prepended_line_number(self, line: str) -> str:
        """Fix the call stack print for pre-pended .mxpy programs:
           - Remove "_prepended.py" extension so the actual user file name is printed
           - Fix the line number so it matches the user's line numbers

        Args:
            line (str): The call stack line to reformat

        Returns:
            str: The reformatted call stack line
        """
        if msb.mxpy_prepended_suffix not in line:
            return line  # Unmodified line

        # Replace the suffix to recover original file name
        line = line.replace(msb.mxpy_prepended_suffix, msb.mxpy_suffix)

        # Search for the line number in the input string and subtract _template_line_offset
        match = re.search(r', line (\d+)', line)
        if match:
            line_number = int(match.group(1))
            new_line_number = line_number - self._template_line_offset
            line = line.replace(f'line {line_number}', f'line {new_line_number}')

        return line
