"""
This is an example advanced Python MecaScript module that registers command:
'ExampleModule.example_reset_robot'
"""
import logging
import time

# Import the robot "initializer" for useful utility functions like reset_motion_queue
import mecademicpy.robot_initializer as initializer

# pylint: disable=wildcard-import,unused-wildcard-import
from mecascript.script_base import *


def example_reset_robot(activate: bool):
    """ Prepare the robot in a well-known state """
    robot.LogTrace(f'example_reset_robot called, activate={activate}', logging.INFO)
    try:
        if activate:
            initializer.reset_motion_queue(robot, activate_home=activate)
        else:
            robot.DeactivateRobot()
    except (InterruptException, DisconnectError) as e:
        robot.LogTrace(f'Program stopping ({e}).', logging.WARNING)
    except StopProgramException as e:
        robot.LogTrace(f'Program stopping ({e}).', logging.INFO)


def demo_moves(duration: float = 60):
    """ Move the robot for the specified duration """
    robot.LogTrace(f'demo_moves called. duration={duration}', logging.INFO)
    loop_count = 0
    start_time = time.monotonic()
    start_pos = [0] * robot.GetRobotInfo().num_joints
    initializer.reset_motion_queue(robot, activate_home=True)
    robot.SetCartLinVel(100)
    robot.SetCartAngVel(500)
    robot.MoveJoints(*start_pos)
    while True:
        if robot.StopProgramRequested():
            robot.LogTrace(f'Program asked to stop. Stopping now', logging.INFO)
            break
        remaining_time = duration - (time.monotonic() - start_time)
        if remaining_time <= 0:
            break
        try:
            loop_count += 1
            robot.MoveLinRelTrf(-20, 20, -20, 0, 0, 90)
            robot.MoveLinRelTrf(-20, 20, 0, 0, 0, 0)
            robot.MoveLinRelTrf(-20, -20, 0, 0, 0, 0)
            robot.MoveLinRelTrf(20, -20, 20, 0, 0, -90)
            loop_checkpoint = robot.SetCheckpoint(loop_count)
            loop_checkpoint.wait(10)
            robot.LogTrace(f'demo_moves loop {loop_count} completed')

            if robot.PauseMotionRequested():
                robot.LogTrace(f'Pausing motion as requested', logging.INFO)
                robot.HandlePauseMotion()
                robot.LogTrace(f'Motion resumed after pause', logging.INFO)

        except (InterruptException, DisconnectError) as e:
            robot.LogTrace(f'Program stopping ({e}).', logging.WARNING)
            break
        except StopProgramException as e:
            if not e.graceful:
                # Stop here, there is nothing we can do anymore with the robot
                robot.LogTrace(f'Program aborted.', logging.WARNING)
                return
            else:
                # Let's continue our graceful stop.
                # We call SetStopProgramInterruption(False) to allow our cleanup
                # code below to continue sending commands to the robot.
                robot.LogTrace(f'Program gracefully stopping ({e}).', logging.INFO)
                robot.SetStopProgramInterruption(False)
                pass
            break

    if robot.IsConnected():
        initializer.reset_error(robot)
        if not robot.GetStatusRobot().end_of_block_status:
            initializer.clear_motion(robot, then_resume=True)
    robot.LogTrace(f'demo_moves done', logging.INFO)


class ExampleModule(MecaScriptBase):
    """ Example class that implements a MecaScript program that registers a robot command. """

    def on_register(self):
        robot.LogTrace(f'ExampleModule is initializing...', logging.INFO)

        # Register a command that will be available as:
        #   programs.mecascript.examples.advanced_example.example_reset_robot
        self.register_command(command=RegisteredCommand(
            function=example_reset_robot,
            name='example_reset_robot',
            cyclic_id=39001,  # Command's unique id for cyclic protocols.
            description=('Resets the robot to a known state.'),
            args=[
                RegisteredArg(name='activate',
                              type=MxArgType.MX_ARG_TYPE_INTEGER,
                              description='Activate (1) or deactivate (0) the robot')
            ],
            command_type=MxRegisteredCmdType.MX_REGISTERED_CMD_TYPE_CONTROLLING))

        # Register a command that will be available as:
        #   programs.mecascript.examples.advanced_example.demo_moves
        self.register_command(command=RegisteredCommand(
            function=demo_moves,
            name='demo_moves',
            cyclic_id=39002,  # Command's unique id for cyclic protocols.
            description=('Perform a demo move in loop until specified duration.'),
            args=[
                RegisteredArg(name='duration',
                              type=MxArgType.MX_ARG_TYPE_FLOAT,
                              description='Duration of this demo move in seconds')
            ],
            command_type=MxRegisteredCmdType.MX_REGISTERED_CMD_TYPE_CONTROLLING))
